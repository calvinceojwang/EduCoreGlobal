-- Fix: Restrict activity log insertions to authenticated users only
DROP POLICY IF EXISTS "System can insert activity logs" ON public.user_activity_logs;

CREATE POLICY "Authenticated users can log own activity" 
ON public.user_activity_logs 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL AND (user_id IS NULL OR auth.uid() = user_id));