-- Create webinar_registrations table
CREATE TABLE public.webinar_registrations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  webinar_id TEXT NOT NULL,
  webinar_title TEXT NOT NULL,
  webinar_date DATE NOT NULL,
  webinar_time TEXT NOT NULL,
  format TEXT NOT NULL DEFAULT 'free',
  amount NUMERIC DEFAULT 0,
  payment_status TEXT NOT NULL DEFAULT 'pending',
  transaction_id TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.webinar_registrations ENABLE ROW LEVEL SECURITY;

-- Users can view their own registrations
CREATE POLICY "Users can view their own webinar registrations"
ON public.webinar_registrations
FOR SELECT
USING (auth.uid() = user_id);

-- Users can insert their own registrations
CREATE POLICY "Users can insert their own webinar registrations"
ON public.webinar_registrations
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Admins can view all registrations
CREATE POLICY "Admins can view all webinar registrations"
ON public.webinar_registrations
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Admins can manage all registrations
CREATE POLICY "Admins can manage webinar registrations"
ON public.webinar_registrations
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Create trigger for updated_at
CREATE TRIGGER update_webinar_registrations_updated_at
BEFORE UPDATE ON public.webinar_registrations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();