import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const DARAJA_CONSUMER_KEY = Deno.env.get('DARAJA_CONSUMER_KEY');
const DARAJA_CONSUMER_SECRET = Deno.env.get('DARAJA_CONSUMER_SECRET');
const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
const SUPABASE_ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY');

// Sandbox configuration - use official Safaricom sandbox test credentials
const DARAJA_BASE_URL = "https://sandbox.safaricom.co.ke";
// Official Safaricom sandbox test shortcode and passkey for Lipa Na M-Pesa Online
const SANDBOX_SHORTCODE = "174379";
const SANDBOX_PASSKEY = "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919";

interface STKPushRequest {
  phone: string;
  amount: number;
  accountReference: string;
  transactionDesc: string;
  callbackUrl?: string;
}

interface QueryRequest {
  checkoutRequestId: string;
}

async function getAccessToken(): Promise<string> {
  console.log("Getting Daraja access token...");
  
  if (!DARAJA_CONSUMER_KEY || !DARAJA_CONSUMER_SECRET) {
    console.error("Daraja credentials missing");
    throw new Error("Daraja API credentials are not configured.");
  }
  
  const auth = btoa(`${DARAJA_CONSUMER_KEY}:${DARAJA_CONSUMER_SECRET}`);
  
  console.log("Requesting token from:", `${DARAJA_BASE_URL}/oauth/v1/generate`);
  
  const response = await fetch(`${DARAJA_BASE_URL}/oauth/v1/generate?grant_type=client_credentials`, {
    method: 'GET',
    headers: {
      'Authorization': `Basic ${auth}`,
    },
  });

  console.log("Token request status:", response.status, response.statusText);

  if (!response.ok) {
    const errorText = await response.text();
    console.error("Failed to get access token:", errorText);
    throw new Error(`Failed to get access token: ${response.status}`);
  }

  const data = await response.json();
  console.log("Access token obtained successfully");
  
  if (!data.access_token) {
    throw new Error("Invalid token response from Safaricom API");
  }
  
  return data.access_token;
}

function formatPhoneNumber(phone: string): string {
  let cleaned = phone.replace(/[\s\-\+]/g, '');
  
  if (cleaned.startsWith('0')) {
    cleaned = '254' + cleaned.substring(1);
  } else if (cleaned.startsWith('7') || cleaned.startsWith('1')) {
    cleaned = '254' + cleaned;
  } else if (!cleaned.startsWith('254')) {
    cleaned = '254' + cleaned;
  }
  
  return cleaned;
}

function generateTimestamp(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  
  return `${year}${month}${day}${hours}${minutes}${seconds}`;
}

function generatePassword(shortcode: string, passkey: string, timestamp: string): string {
  const dataStr = `${shortcode}${passkey}${timestamp}`;
  return btoa(dataStr);
}

// Sanitize string to remove special characters that could break XML parsing
function sanitizeForMpesa(str: string): string {
  return str.replace(/[&<>"']/g, '').replace(/\s+/g, ' ').trim();
}

async function handleSTKPush(body: STKPushRequest, userId: string, accessToken: string): Promise<Response> {
  const { phone, amount, accountReference, transactionDesc, callbackUrl } = body;

  if (!phone || !amount || !accountReference) {
    throw new Error("Missing required fields: phone, amount, accountReference");
  }

  if (amount <= 0) {
    throw new Error("Amount must be a positive number");
  }

  console.log("Processing STK Push for user:", userId, { phone, amount, accountReference });

  const formattedPhone = formatPhoneNumber(phone);
  console.log("Formatted phone:", formattedPhone);

  const timestamp = generateTimestamp();
  const password = generatePassword(SANDBOX_SHORTCODE, SANDBOX_PASSKEY, timestamp);

  const defaultCallbackUrl = `${SUPABASE_URL}/functions/v1/mpesa-callback`;

  const stkPushPayload = {
    BusinessShortCode: SANDBOX_SHORTCODE,
    Password: password,
    Timestamp: timestamp,
    TransactionType: "CustomerPayBillOnline",
    Amount: Math.round(amount),
    PartyA: formattedPhone,
    PartyB: SANDBOX_SHORTCODE,
    PhoneNumber: formattedPhone,
    CallBackURL: callbackUrl || defaultCallbackUrl,
    AccountReference: sanitizeForMpesa(accountReference).substring(0, 12) || "Payment",
    TransactionDesc: sanitizeForMpesa(transactionDesc || "Payment").substring(0, 13),
  };

  console.log("STK Push payload:", JSON.stringify(stkPushPayload));

  const stkResponse = await fetch(`${DARAJA_BASE_URL}/mpesa/stkpush/v1/processrequest`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(stkPushPayload),
  });

  console.log("STK Push response status:", stkResponse.status, stkResponse.statusText);
  const stkResult = await stkResponse.json();
  console.log("Daraja API response:", JSON.stringify(stkResult));

  if (stkResult.ResponseCode === "0") {
    console.log("STK Push sent successfully");
    return new Response(JSON.stringify({
      success: true,
      message: "STK Push sent successfully",
      checkoutRequestId: stkResult.CheckoutRequestID,
      merchantRequestId: stkResult.MerchantRequestID,
      responseDescription: stkResult.ResponseDescription,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } else {
    console.error("STK Push failed:", stkResult);
    return new Response(JSON.stringify({
      success: false,
      message: stkResult.errorMessage || stkResult.ResponseDescription || "STK Push failed",
      errorCode: stkResult.errorCode || stkResult.ResponseCode,
    }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
}

async function handleQuery(body: QueryRequest, accessToken: string): Promise<Response> {
  const { checkoutRequestId } = body;

  if (!checkoutRequestId) {
    throw new Error("Missing required field: checkoutRequestId");
  }

  console.log("Querying transaction status for:", checkoutRequestId);

  const timestamp = generateTimestamp();
  const password = generatePassword(SANDBOX_SHORTCODE, SANDBOX_PASSKEY, timestamp);

  const queryPayload = {
    BusinessShortCode: SANDBOX_SHORTCODE,
    Password: password,
    Timestamp: timestamp,
    CheckoutRequestID: checkoutRequestId,
  };

  console.log("Query payload:", JSON.stringify(queryPayload));

  const queryResponse = await fetch(`${DARAJA_BASE_URL}/mpesa/stkpushquery/v1/query`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(queryPayload),
  });

  console.log("Query response status:", queryResponse.status, queryResponse.statusText);
  const queryResult = await queryResponse.json();
  console.log("Query API response:", JSON.stringify(queryResult));

  if (queryResult.ResponseCode === "0") {
    return new Response(JSON.stringify({
      success: true,
      resultCode: queryResult.ResultCode,
      resultDesc: queryResult.ResultDesc,
      merchantRequestId: queryResult.MerchantRequestID,
      checkoutRequestId: queryResult.CheckoutRequestID,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } else {
    return new Response(JSON.stringify({
      success: false,
      message: queryResult.errorMessage || queryResult.ResponseDescription || "Query failed",
      errorCode: queryResult.errorCode || queryResult.ResponseCode,
    }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ 
        success: false, 
        message: 'Authentication required' 
      }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
      throw new Error("Server configuration error");
    }

    const supabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
    if (authError || !user) {
      return new Response(JSON.stringify({ 
        success: false, 
        message: 'Invalid or expired authentication' 
      }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log("User authenticated:", user.id);

    if (!DARAJA_CONSUMER_KEY || !DARAJA_CONSUMER_SECRET) {
      throw new Error("Missing Daraja API credentials");
    }

    const body = await req.json();
    const accessToken = await getAccessToken();

    // Determine action based on request body
    if (body.action === 'query' && body.checkoutRequestId) {
      return await handleQuery(body, accessToken);
    } else {
      return await handleSTKPush(body, user.id, accessToken);
    }

  } catch (error: unknown) {
    console.error('Error in mpesa-stk-push function:', error);
    const errorMessage = error instanceof Error ? error.message : "An error occurred";
    return new Response(JSON.stringify({
      success: false,
      message: errorMessage,
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
