import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const callback = await req.json();
    console.log("M-Pesa callback received:", JSON.stringify(callback, null, 2));

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Extract callback data
    const body = callback.Body?.stkCallback;
    
    if (!body) {
      console.error("Invalid callback structure");
      return new Response(JSON.stringify({ ResultCode: 0, ResultDesc: "Accepted" }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const checkoutRequestId = body.CheckoutRequestID;
    const resultCode = body.ResultCode;
    const resultDesc = body.ResultDesc;

    // Validate checkoutRequestId format (basic validation)
    if (!checkoutRequestId || typeof checkoutRequestId !== 'string' || checkoutRequestId.length < 10) {
      console.error("Invalid CheckoutRequestID format:", checkoutRequestId);
      return new Response(JSON.stringify({ ResultCode: 0, ResultDesc: "Accepted" }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log("Callback details:", { checkoutRequestId, resultCode, resultDesc });

    // SECURITY: Verify the transaction exists in our database before processing
    const { data: existingPayment, error: fetchError } = await supabase
      .from('payments')
      .select('id, amount, payment_status')
      .eq('transaction_id', checkoutRequestId)
      .single();

    if (fetchError || !existingPayment) {
      console.error("No payment found for CheckoutRequestID:", checkoutRequestId, fetchError);
      // Return success to prevent retries but don't update anything
      return new Response(JSON.stringify({ ResultCode: 0, ResultDesc: "Accepted" }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // SECURITY: Check if already processed (idempotency)
    if (existingPayment.payment_status === 'completed') {
      console.log("Payment already completed, skipping:", checkoutRequestId);
      return new Response(JSON.stringify({ ResultCode: 0, ResultDesc: "Already processed" }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (existingPayment.payment_status === 'failed') {
      console.log("Payment already marked as failed, skipping:", checkoutRequestId);
      return new Response(JSON.stringify({ ResultCode: 0, ResultDesc: "Already processed" }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (resultCode === 0) {
      // Payment successful - extract callback metadata
      const metadata = body.CallbackMetadata?.Item || [];
      
      const getMetadataValue = (name: string) => {
        const item = metadata.find((m: any) => m.Name === name);
        return item?.Value;
      };

      const amount = getMetadataValue('Amount');
      const mpesaReceiptNumber = getMetadataValue('MpesaReceiptNumber');
      const transactionDate = getMetadataValue('TransactionDate');
      const phoneNumber = getMetadataValue('PhoneNumber');

      console.log("Payment successful:", { amount, mpesaReceiptNumber, transactionDate, phoneNumber });

      // SECURITY: Verify amount matches (within tolerance for rounding)
      if (amount && existingPayment.amount) {
        const amountDiff = Math.abs(Number(existingPayment.amount) - Number(amount));
        if (amountDiff > 1) {
          console.error("Amount mismatch detected:", {
            expected: existingPayment.amount,
            received: amount,
            checkoutRequestId
          });
          // Flag for manual review - don't auto-complete
          const { error: flagError } = await supabase
            .from('payments')
            .update({
              payment_status: 'pending_review',
              updated_at: new Date().toISOString(),
            })
            .eq('id', existingPayment.id)
            .eq('payment_status', 'pending');
          
          if (flagError) {
            console.error("Error flagging payment for review:", flagError);
          }
          return new Response(JSON.stringify({ ResultCode: 0, ResultDesc: "Accepted" }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
      }

      // SECURITY: Only update if still pending (idempotency protection)
      const { error: updateError, count } = await supabase
        .from('payments')
        .update({
          payment_status: 'completed',
          transaction_id: mpesaReceiptNumber,
          updated_at: new Date().toISOString(),
        })
        .eq('id', existingPayment.id)
        .eq('payment_status', 'pending');

      if (updateError) {
        console.error("Error updating payment record:", updateError);
      } else {
        console.log("Payment record updated successfully");
      }
    } else {
      // Payment failed or cancelled
      console.log("Payment failed or cancelled:", resultDesc);

      // SECURITY: Only update if still pending
      const { error: updateError } = await supabase
        .from('payments')
        .update({
          payment_status: 'failed',
          updated_at: new Date().toISOString(),
        })
        .eq('id', existingPayment.id)
        .eq('payment_status', 'pending');

      if (updateError) {
        console.error("Error updating payment record:", updateError);
      }
    }

    // Always respond with success to Safaricom
    return new Response(JSON.stringify({ ResultCode: 0, ResultDesc: "Accepted" }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error in mpesa-callback function:', error);
    // Still return success to Safaricom
    return new Response(JSON.stringify({ ResultCode: 0, ResultDesc: "Accepted" }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
