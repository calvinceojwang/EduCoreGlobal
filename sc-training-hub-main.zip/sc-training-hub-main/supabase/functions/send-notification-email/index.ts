import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface EmailRequest {
  type: "booking_confirmation" | "webinar_registration";
  to: string;
  data: {
    courseName?: string;
    webinarName?: string;
    date?: string;
    time?: string;
    trainingType?: string;
    amount?: number;
    currency?: string;
    participantCount?: number;
  };
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { type, to, data }: EmailRequest = await req.json();

    let subject = "";
    let html = "";

    if (type === "booking_confirmation") {
      subject = `Booking Confirmed: ${data.courseName}`;
      html = `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #0066cc, #0099ff); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }
            .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #eee; }
            .detail-label { font-weight: bold; width: 150px; }
            .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
            .highlight { background: #e6f3ff; padding: 15px; border-radius: 8px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🎓 Booking Confirmed!</h1>
            </div>
            <div class="content">
              <p>Dear Learner,</p>
              <p>Your training course has been successfully booked. Here are the details:</p>
              
              <div class="highlight">
                <div class="detail-row">
                  <span class="detail-label">Course:</span>
                  <span>${data.courseName}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-label">Date:</span>
                  <span>${data.date}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-label">Time:</span>
                  <span>${data.time}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-label">Training Type:</span>
                  <span>${data.trainingType}</span>
                </div>
                ${data.participantCount && data.participantCount > 1 ? `
                <div class="detail-row">
                  <span class="detail-label">Participants:</span>
                  <span>${data.participantCount} people</span>
                </div>
                ` : ''}
                <div class="detail-row">
                  <span class="detail-label">Amount Paid:</span>
                  <span><strong>${data.currency} ${data.amount?.toLocaleString()}</strong></span>
                </div>
              </div>
              
              <p>We look forward to seeing you in the training session!</p>
              <p>If you have any questions, please don't hesitate to contact our support team.</p>
              
              <p>Best regards,<br>The Training Team</p>
            </div>
            <div class="footer">
              <p>This is an automated email. Please do not reply directly to this message.</p>
            </div>
          </div>
        </body>
        </html>
      `;
    } else if (type === "webinar_registration") {
      subject = `Registration Confirmed: ${data.webinarName}`;
      html = `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #0066cc, #0099ff); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }
            .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #eee; }
            .detail-label { font-weight: bold; width: 150px; }
            .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
            .highlight { background: #e6f3ff; padding: 15px; border-radius: 8px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>📺 Webinar Registration Confirmed!</h1>
            </div>
            <div class="content">
              <p>Dear Participant,</p>
              <p>You have successfully registered for our webinar. Here are the details:</p>
              
              <div class="highlight">
                <div class="detail-row">
                  <span class="detail-label">Webinar:</span>
                  <span>${data.webinarName}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-label">Date:</span>
                  <span>${data.date}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-label">Time:</span>
                  <span>${data.time}</span>
                </div>
                ${data.amount && data.amount > 0 ? `
                <div class="detail-row">
                  <span class="detail-label">Amount Paid:</span>
                  <span><strong>KES ${data.amount?.toLocaleString()}</strong></span>
                </div>
                ` : `
                <div class="detail-row">
                  <span class="detail-label">Type:</span>
                  <span>Free Webinar</span>
                </div>
                `}
              </div>
              
              <p>You will receive a reminder email with the joining link before the webinar starts.</p>
              <p>If you have any questions, please don't hesitate to contact our support team.</p>
              
              <p>Best regards,<br>The Webinars Team</p>
            </div>
            <div class="footer">
              <p>This is an automated email. Please do not reply directly to this message.</p>
            </div>
          </div>
        </body>
        </html>
      `;
    }

    if (!RESEND_API_KEY) {
      throw new Error("RESEND_API_KEY is not configured");
    }

    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "Training Platform <onboarding@resend.dev>",
        to: [to],
        subject,
        html,
      }),
    });

    const emailResult = await emailResponse.json();

    console.log("Email sent successfully:", emailResult);

    return new Response(JSON.stringify(emailResult), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error in send-notification-email function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
