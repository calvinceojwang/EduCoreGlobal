import { useState, useMemo } from "react";
import { useParams } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { CourseCard } from "@/components/training/CourseCard";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Filter, MapPin } from "lucide-react";

const destinations: Record<string, { name: string; country: string }> = {
  "virtual": { name: "Virtual (Zoom)", country: "Online" },
  "nairobi-ke": { name: "Nairobi", country: "Kenya" },
  "kigali-rw": { name: "Kigali", country: "Rwanda" },
  "dubai-uae": { name: "Dubai", country: "United Arab Emirates" },
  "kampala-ug": { name: "Kampala", country: "Uganda" },
  "zanzibar-tz": { name: "Zanzibar", country: "Tanzania" },
  "mombasa-ke": { name: "Mombasa", country: "Kenya" },
  "johannesburg-za": { name: "Johannesburg", country: "South Africa" },
  "capetown-za": { name: "Cape Town", country: "South Africa" },
  "pretoria-za": { name: "Pretoria", country: "South Africa" },
  "naivasha-ke": { name: "Naivasha", country: "Kenya" },
  "nakuru-ke": { name: "Nakuru", country: "Kenya" },
  "kisumu-ke": { name: "Kisumu", country: "Kenya" },
  "kualalumpur-my": { name: "Kuala Lumpur", country: "Malaysia" },
  "jeddah-sa": { name: "Jeddah", country: "Saudi Arabia" },
  "dar-tz": { name: "Dar es Salaam", country: "Tanzania" },
  "singapore-sg": { name: "Singapore", country: "Singapore" },
  "arusha-tz": { name: "Arusha", country: "Tanzania" },
  "lagos-ng": { name: "Lagos", country: "Nigeria" },
  "abuja-ng": { name: "Abuja", country: "Nigeria" },
  "accra-gh": { name: "Accra", country: "Ghana" },
  "riyadh-sa": { name: "Riyadh", country: "Saudi Arabia" },
};

const allCourses = [
  { id: "1", title: "Software Testing Fundamentals", category: "Quality Assurance", duration: "5 Days", price: 42000, image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600&h=400&fit=crop", rating: 4.8, students: 1560 },
  { id: "2", title: "Automated Testing with Selenium", category: "Quality Assurance", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=600&h=400&fit=crop", rating: 4.7, students: 1340 },
  { id: "10", title: "Data Science with Python", category: "Data Science", duration: "5 Days", price: 58000, image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop", rating: 4.9, students: 2340 },
  { id: "11", title: "Machine Learning Fundamentals", category: "Data Science", duration: "5 Days", price: 62000, image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=600&h=400&fit=crop", rating: 4.8, students: 1980 },
  { id: "18", title: "Project Management Professional (PMP)", category: "Project Management", duration: "5 Days", price: 70000, image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop", rating: 4.9, students: 2890 },
  { id: "19", title: "Agile & Scrum Mastery", category: "Project Management", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=600&h=400&fit=crop", rating: 4.8, students: 2340 },
  { id: "35", title: "Full Stack Web Development", category: "Information Technology", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600&h=400&fit=crop", rating: 4.9, students: 2890 },
  { id: "36", title: "Cloud Computing with AWS", category: "Information Technology", duration: "5 Days", price: 58000, image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600&h=400&fit=crop", rating: 4.8, students: 2340 },
  { id: "59", title: "Executive Leadership Program", category: "Leadership", duration: "5 Days", price: 75000, image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=600&h=400&fit=crop", rating: 4.9, students: 1890 },
  { id: "66", title: "Cybersecurity Fundamentals", category: "Cyber Security", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=600&h=400&fit=crop", rating: 4.9, students: 2120 },
  { id: "74", title: "Digital Marketing Mastery", category: "Marketing", duration: "5 Days", price: 42000, image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop", rating: 4.8, students: 2890 },
  { id: "41", title: "Data Analytics with Power BI", category: "Data Analytics", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop", rating: 4.8, students: 2670 },
];

const categories = [
  { value: "all", label: "All Categories" },
  { value: "Quality Assurance", label: "Quality Assurance" },
  { value: "Data Science", label: "Data Science" },
  { value: "Project Management", label: "Project Management" },
  { value: "Information Technology", label: "Information Technology" },
  { value: "Leadership", label: "Leadership" },
  { value: "Cyber Security", label: "Cyber Security" },
  { value: "Marketing", label: "Marketing" },
  { value: "Data Analytics", label: "Data Analytics" },
];

const Destinations = () => {
  const { code } = useParams<{ code: string }>();
  const destination = destinations[code || ""] || { name: "Unknown", country: "Unknown" };
  
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [skillLevel, setSkillLevel] = useState("all");

  const filteredCourses = useMemo(() => {
    let courses = [...allCourses];
    
    if (search) {
      const searchLower = search.toLowerCase();
      courses = courses.filter(
        (c) =>
          c.title.toLowerCase().includes(searchLower) ||
          c.category.toLowerCase().includes(searchLower)
      );
    }
    
    if (category !== "all") {
      courses = courses.filter((c) => c.category === category);
    }
    
    return courses;
  }, [search, category]);

  const displayName = code === "virtual" 
    ? "Virtual Training Sessions" 
    : `${destination.name}, ${destination.country}`;

  return (
    <Layout>
      {/* Header */}
      <section className="hero-gradient py-16 lg:py-24">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <MapPin className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-3xl lg:text-5xl font-bold text-primary-foreground mb-4">
            Training Sessions in <span className="text-accent">{displayName}</span>
          </h1>
          <p className="text-lg text-primary-foreground/80 max-w-3xl mx-auto leading-relaxed">
            Welcome to {destination.name} – a hub of learning and innovation! Our training courses are crafted for ambitious professionals who are ready to level up their skills and make a meaningful impact. From leadership and management to tech and digital transformation, each course is tailored to meet the demands of today's fast-paced industries. Engage with top-notch instructors, connect with a vibrant community of like-minded learners, and leave equipped to tackle real-world challenges with confidence.
          </p>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-card border-b border-border sticky top-16 lg:top-20 z-40">
        <div className="container mx-auto px-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search courses..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="sm:w-56">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat.value} value={cat.value}>
                    {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={skillLevel} onValueChange={setSkillLevel}>
              <SelectTrigger className="sm:w-48">
                <SelectValue placeholder="Skill Level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="beginner">Beginner</SelectItem>
                <SelectItem value="intermediate">Intermediate</SelectItem>
                <SelectItem value="advanced">Advanced</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      {/* Courses Grid */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <p className="text-muted-foreground mb-6">
            Showing {filteredCourses.length} courses available in {displayName}
          </p>
          
          {filteredCourses.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {filteredCourses.map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <p className="text-xl text-muted-foreground">No courses found</p>
              <p className="text-sm text-muted-foreground mt-2">
                Try adjusting your search or filters
              </p>
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
};

export default Destinations;
