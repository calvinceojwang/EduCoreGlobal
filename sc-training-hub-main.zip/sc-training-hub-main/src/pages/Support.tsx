import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Search, MessageCircle, Mail, Phone, FileText, CreditCard, Calendar, User } from "lucide-react";
import { Link } from "react-router-dom";

const categories = [
  { icon: FileText, name: "Getting Started", count: 8 },
  { icon: Calendar, name: "Booking & Scheduling", count: 12 },
  { icon: CreditCard, name: "Payments & Refunds", count: 10 },
  { icon: User, name: "Account & Profile", count: 6 },
];

const faqs = [
  {
    question: "How do I enroll in a course?",
    answer: "Simply browse our training catalog, select your preferred course, choose your date and time, select physical or virtual training, and proceed to payment. You'll receive a confirmation email once your booking is complete.",
  },
  {
    question: "What payment methods do you accept?",
    answer: "We accept M-Pesa, Visa, Mastercard, and bank transfers. For M-Pesa, you'll receive an STK push on your phone. For card payments, we use secure 3D authentication.",
  },
  {
    question: "Can I get a refund if I can't attend?",
    answer: "Yes, we offer full refunds for cancellations made at least 7 days before the training start date. Cancellations within 7 days may be eligible for rescheduling or a 50% refund.",
  },
  {
    question: "Do you offer virtual training?",
    answer: "Absolutely! All our courses are available in both physical (at our Nairobi center) and virtual (via Zoom) formats. Virtual students receive the same materials and certification.",
  },
  {
    question: "How long are the training programs?",
    answer: "All our courses and certification programs run for 5 days. Classes typically run from 9 AM to 5 PM with breaks included.",
  },
  {
    question: "Will I receive a certificate?",
    answer: "Yes, all students who successfully complete their training receive a certificate of completion. For professional certifications like CPA and AWS, additional exams may be required.",
  },
  {
    question: "Do you offer corporate training?",
    answer: "Yes, we offer customized corporate training programs. Contact us for group discounts and tailored curricula for your organization's needs.",
  },
  {
    question: "What if I need to reschedule?",
    answer: "You can reschedule your training up to 48 hours before the start date at no extra cost. Simply log into your account or contact our support team.",
  },
];

const Support = () => {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredFaqs = faqs.filter(
    (faq) =>
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Layout>
      {/* Hero */}
      <section className="hero-gradient py-16 lg:py-24">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl lg:text-5xl font-bold text-primary-foreground mb-4">
            How Can We Help?
          </h1>
          <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto mb-8">
            Search our knowledge base or contact our support team
          </p>
          <div className="max-w-xl mx-auto relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Search for help..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 h-14 text-lg bg-white border-0"
            />
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {categories.map((cat) => (
              <div
                key={cat.name}
                className="p-6 bg-card rounded-xl card-shadow hover:card-shadow-hover transition-all cursor-pointer group"
              >
                <cat.icon className="w-8 h-8 text-primary mb-4" />
                <h3 className="font-semibold group-hover:text-primary transition-colors">
                  {cat.name}
                </h3>
                <p className="text-sm text-muted-foreground">{cat.count} articles</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-12 bg-muted/50" id="faq">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl lg:text-3xl font-bold text-center mb-8">
            Frequently Asked Questions
          </h2>
          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="space-y-3">
              {filteredFaqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="bg-card rounded-xl px-6 border-0 card-shadow"
                >
                  <AccordionTrigger className="text-left hover:no-underline py-5">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground pb-5">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
            {filteredFaqs.length === 0 && (
              <p className="text-center text-muted-foreground py-8">
                No results found for "{searchQuery}"
              </p>
            )}
          </div>
        </div>
      </section>

      {/* Contact Options */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl lg:text-3xl font-bold text-center mb-4">
            Still Need Help?
          </h2>
          <p className="text-muted-foreground text-center mb-12">
            Our support team is here to assist you
          </p>
          <div className="grid sm:grid-cols-3 gap-6 max-w-3xl mx-auto">
            <div className="p-6 bg-card rounded-2xl card-shadow text-center">
              <div className="w-14 h-14 rounded-xl hero-gradient flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="w-7 h-7 text-primary-foreground" />
              </div>
              <h3 className="font-semibold mb-2">Live Chat</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Chat with our team in real-time
              </p>
              <Button variant="outline" size="sm">
                Start Chat
              </Button>
            </div>
            <div className="p-6 bg-card rounded-2xl card-shadow text-center">
              <div className="w-14 h-14 rounded-xl bg-accent flex items-center justify-center mx-auto mb-4">
                <Mail className="w-7 h-7 text-accent-foreground" />
              </div>
              <h3 className="font-semibold mb-2">Email Us</h3>
              <p className="text-sm text-muted-foreground mb-4">
                We respond within 24 hours
              </p>
              <Link to="/contact">
                <Button variant="outline" size="sm">
                  Send Email
                </Button>
              </Link>
            </div>
            <div className="p-6 bg-card rounded-2xl card-shadow text-center">
              <div className="w-14 h-14 rounded-xl bg-green-500/10 flex items-center justify-center mx-auto mb-4">
                <Phone className="w-7 h-7 text-green-600" />
              </div>
              <h3 className="font-semibold mb-2">Call Us</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Mon-Fri, 8 AM - 6 PM
              </p>
              <Button variant="outline" size="sm" asChild>
                <a href="tel:+254700000000">+254 700 000 000</a>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Support;
