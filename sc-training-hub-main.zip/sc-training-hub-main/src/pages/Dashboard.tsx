import { useEffect, useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { BookOpen, Calendar, CreditCard, Clock, MapPin, Users, Video, CheckCircle, XCircle, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { format } from "date-fns";

interface Payment {
  id: string;
  course_title: string;
  amount: number;
  currency: string;
  payment_method: string;
  payment_status: string;
  training_date: string | null;
  training_time: string | null;
  training_type: string | null;
  created_at: string;
  transaction_id: string | null;
}

interface WebinarRegistration {
  id: string;
  webinar_title: string;
  webinar_date: string;
  webinar_time: string;
  format: string;
  amount: number;
  payment_status: string;
  created_at: string;
}

const Dashboard = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [webinarRegistrations, setWebinarRegistrations] = useState<WebinarRegistration[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/login");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (user) {
      fetchUserData();
    }
  }, [user]);

  const fetchUserData = async () => {
    setLoading(true);
    try {
      // Fetch payments (booked courses)
      const { data: paymentsData, error: paymentsError } = await supabase
        .from("payments")
        .select("*")
        .eq("user_id", user?.id)
        .order("created_at", { ascending: false });

      if (paymentsError) {
        console.error("Error fetching payments:", paymentsError);
      } else {
        setPayments(paymentsData || []);
      }

      // Fetch webinar registrations
      const { data: webinarsData, error: webinarsError } = await supabase
        .from("webinar_registrations")
        .select("*")
        .eq("user_id", user?.id)
        .order("created_at", { ascending: false });

      if (webinarsError) {
        console.error("Error fetching webinar registrations:", webinarsError);
      } else {
        setWebinarRegistrations(webinarsData || []);
      }
    } catch (error) {
      console.error("Error fetching user data:", error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
      case "success":
        return <Badge className="bg-green-100 text-green-700"><CheckCircle className="w-3 h-3 mr-1" />Completed</Badge>;
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-700"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case "failed":
        return <Badge className="bg-red-100 text-red-700"><XCircle className="w-3 h-3 mr-1" />Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const bookedCourses = payments.filter(p => p.payment_status === "completed" || p.payment_status === "success");
  const confirmedWebinars = webinarRegistrations.filter(w => w.payment_status === "completed" || w.payment_status === "success" || w.format === "free");

  if (authLoading) {
    return (
      <Layout>
        <div className="min-h-[60vh] flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      {/* Header */}
      <section className="hero-gradient py-12 lg:py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl lg:text-4xl font-bold text-primary-foreground mb-2">
            My Dashboard
          </h1>
          <p className="text-primary-foreground/80">
            Welcome back, {user?.email}
          </p>
        </div>
      </section>

      {/* Stats Cards */}
      <section className="py-8 bg-card border-b border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Booked Courses</CardTitle>
                <BookOpen className="w-5 h-5 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{bookedCourses.length}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Registered Webinars</CardTitle>
                <Video className="w-5 h-5 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{confirmedWebinars.length}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Transactions</CardTitle>
                <CreditCard className="w-5 h-5 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{payments.length + webinarRegistrations.length}</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <Tabs defaultValue="courses" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="courses">Booked Courses</TabsTrigger>
              <TabsTrigger value="webinars">Webinars</TabsTrigger>
              <TabsTrigger value="payments">Payment History</TabsTrigger>
            </TabsList>

            {/* Booked Courses Tab */}
            <TabsContent value="courses">
              {loading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : bookedCourses.length > 0 ? (
                <div className="grid gap-4">
                  {bookedCourses.map((payment) => (
                    <Card key={payment.id}>
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold mb-2">{payment.course_title}</h3>
                            <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                              {payment.training_date && (
                                <div className="flex items-center gap-1">
                                  <Calendar className="w-4 h-4" />
                                  {format(new Date(payment.training_date), "MMM dd, yyyy")}
                                </div>
                              )}
                              {payment.training_time && (
                                <div className="flex items-center gap-1">
                                  <Clock className="w-4 h-4" />
                                  {payment.training_time}
                                </div>
                              )}
                              {payment.training_type && (
                                <div className="flex items-center gap-1">
                                  <MapPin className="w-4 h-4" />
                                  {payment.training_type}
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            {getStatusBadge(payment.payment_status)}
                            <span className="font-semibold text-primary">
                              {payment.currency} {payment.amount.toLocaleString()}
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="py-12 text-center">
                    <BookOpen className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No courses booked yet</h3>
                    <p className="text-muted-foreground mb-4">Start your learning journey by booking a course</p>
                    <Button onClick={() => navigate("/training")}>Browse Courses</Button>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Webinars Tab */}
            <TabsContent value="webinars">
              {loading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : confirmedWebinars.length > 0 ? (
                <div className="grid gap-4">
                  {confirmedWebinars.map((registration) => (
                    <Card key={registration.id}>
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold mb-2">{registration.webinar_title}</h3>
                            <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <Calendar className="w-4 h-4" />
                                {format(new Date(registration.webinar_date), "MMM dd, yyyy")}
                              </div>
                              <div className="flex items-center gap-1">
                                <Clock className="w-4 h-4" />
                                {registration.webinar_time}
                              </div>
                              <Badge variant={registration.format === "free" ? "secondary" : "default"}>
                                {registration.format === "free" ? "Free" : `KES ${registration.amount}`}
                              </Badge>
                            </div>
                          </div>
                          <div>
                            {getStatusBadge(registration.format === "free" ? "completed" : registration.payment_status)}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="py-12 text-center">
                    <Video className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No webinars registered</h3>
                    <p className="text-muted-foreground mb-4">Join our expert-led webinars to enhance your skills</p>
                    <Button onClick={() => navigate("/webinars")}>Browse Webinars</Button>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Payment History Tab */}
            <TabsContent value="payments">
              {loading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : payments.length > 0 || webinarRegistrations.length > 0 ? (
                <div className="space-y-4">
                  {/* Course Payments */}
                  {payments.map((payment) => (
                    <Card key={payment.id}>
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <BookOpen className="w-4 h-4 text-primary" />
                              <span className="text-sm text-muted-foreground">Course Booking</span>
                            </div>
                            <h3 className="font-semibold">{payment.course_title}</h3>
                            <p className="text-sm text-muted-foreground">
                              {format(new Date(payment.created_at), "MMM dd, yyyy 'at' h:mm a")}
                            </p>
                          </div>
                          <div className="flex items-center gap-4">
                            <Badge variant="outline">{payment.payment_method}</Badge>
                            {getStatusBadge(payment.payment_status)}
                            <span className="font-semibold">
                              {payment.currency} {payment.amount.toLocaleString()}
                            </span>
                          </div>
                        </div>
                        {payment.transaction_id && (
                          <p className="text-xs text-muted-foreground mt-2">
                            Transaction ID: {payment.transaction_id}
                          </p>
                        )}
                      </CardContent>
                    </Card>
                  ))}

                  {/* Webinar Payments */}
                  {webinarRegistrations.filter(w => w.format === "paid").map((registration) => (
                    <Card key={registration.id}>
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Video className="w-4 h-4 text-primary" />
                              <span className="text-sm text-muted-foreground">Webinar Registration</span>
                            </div>
                            <h3 className="font-semibold">{registration.webinar_title}</h3>
                            <p className="text-sm text-muted-foreground">
                              {format(new Date(registration.created_at), "MMM dd, yyyy 'at' h:mm a")}
                            </p>
                          </div>
                          <div className="flex items-center gap-4">
                            <Badge variant="outline">M-Pesa</Badge>
                            {getStatusBadge(registration.payment_status)}
                            <span className="font-semibold">
                              KES {registration.amount.toLocaleString()}
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="py-12 text-center">
                    <CreditCard className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No payment history</h3>
                    <p className="text-muted-foreground">Your payment transactions will appear here</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </Layout>
  );
};

export default Dashboard;
