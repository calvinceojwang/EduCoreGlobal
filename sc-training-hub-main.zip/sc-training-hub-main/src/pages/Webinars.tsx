import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, Calendar, Users, Video, Clock, CheckCircle, Smartphone } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Label } from "@/components/ui/label";

interface Webinar {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  duration: string;
  format: "free" | "paid";
  price?: number;
  status: "draft" | "scheduled" | "live" | "completed" | "cancelled";
  participants: number;
  instructor: string;
  category: string;
  image: string;
}

const webinars: Webinar[] = [
  {
    id: "1",
    title: "Introduction to Cloud Computing",
    description: "Learn the fundamentals of cloud infrastructure and services",
    date: "2026-01-15",
    time: "10:00 AM",
    duration: "2 hours",
    format: "free",
    status: "scheduled",
    participants: 156,
    instructor: "Dr. James Ochieng",
    category: "Technology",
    image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600&h=400&fit=crop",
  },
  {
    id: "2",
    title: "Data Analytics Masterclass",
    description: "Advanced techniques in data analysis and visualization",
    date: "2026-01-20",
    time: "2:00 PM",
    duration: "3 hours",
    format: "paid",
    price: 2500,
    status: "scheduled",
    participants: 89,
    instructor: "Prof. Sarah Mwangi",
    category: "Data Science",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop",
  },
  {
    id: "3",
    title: "Project Management Essentials",
    description: "Core skills for effective project management",
    date: "2026-01-25",
    time: "9:00 AM",
    duration: "2.5 hours",
    format: "free",
    status: "scheduled",
    participants: 234,
    instructor: "Dr. Peter Kiarie",
    category: "Management",
    image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop",
  },
  {
    id: "4",
    title: "Cybersecurity Best Practices",
    description: "Protect your organization from cyber threats",
    date: "2025-12-20",
    time: "11:00 AM",
    duration: "2 hours",
    format: "paid",
    price: 3000,
    status: "completed",
    participants: 412,
    instructor: "Eng. Michael Njoroge",
    category: "Cyber Security",
    image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=600&h=400&fit=crop",
  },
  {
    id: "5",
    title: "Financial Modeling with Excel",
    description: "Build professional financial models from scratch",
    date: "2025-12-15",
    time: "3:00 PM",
    duration: "3 hours",
    format: "paid",
    price: 3500,
    status: "completed",
    participants: 178,
    instructor: "CPA Mary Wanjiru",
    category: "Finance",
    image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&h=400&fit=crop",
  },
  {
    id: "6",
    title: "AI & Machine Learning Trends 2026",
    description: "Explore the latest developments in artificial intelligence",
    date: "2026-02-01",
    time: "1:00 PM",
    duration: "2 hours",
    format: "free",
    status: "scheduled",
    participants: 567,
    instructor: "Dr. Amina Hassan",
    category: "Technology",
    image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=600&h=400&fit=crop",
  },
  {
    id: "7",
    title: "Leadership in Digital Age",
    description: "Transform your leadership skills for the modern workplace",
    date: "2026-01-04",
    time: "10:00 AM",
    duration: "2 hours",
    format: "paid",
    price: 2000,
    status: "live",
    participants: 321,
    instructor: "Prof. David Kimani",
    category: "Leadership",
    image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=600&h=400&fit=crop",
  },
];

const Webinars = () => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [formatFilter, setFormatFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedWebinar, setSelectedWebinar] = useState<Webinar | null>(null);
  const [mpesaPhone, setMpesaPhone] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);

  const upcomingWebinars = webinars.filter(w => w.status === "scheduled" || w.status === "live");
  const completedWebinars = webinars.filter(w => w.status === "completed");
  const totalParticipants = webinars.reduce((acc, w) => acc + w.participants, 0);

  const filteredWebinars = webinars.filter(webinar => {
    const matchesSearch = webinar.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         webinar.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         webinar.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFormat = formatFilter === "all" || webinar.format === formatFilter;
    const matchesStatus = statusFilter === "all" || webinar.status === statusFilter;
    return matchesSearch && matchesFormat && matchesStatus;
  });

  const handleRegister = async (webinar: Webinar) => {
    if (!user) {
      toast.error("Please log in to register for webinars");
      return;
    }

    if (webinar.format === "paid") {
      setSelectedWebinar(webinar);
      setShowPaymentModal(true);
    } else {
      // Free webinar - save registration to database
      try {
        const { error } = await supabase
          .from("webinar_registrations")
          .insert({
            user_id: user.id,
            webinar_id: webinar.id,
            webinar_title: webinar.title,
            webinar_date: webinar.date,
            webinar_time: webinar.time,
            format: webinar.format,
            amount: 0,
            payment_status: "completed",
          });

        if (error) {
          console.error("Registration error:", error);
          toast.error("Failed to register. Please try again.");
          return;
        }

        // Send email notification
        try {
          await supabase.functions.invoke('send-notification-email', {
            body: {
              type: "webinar_registration",
              to: user.email,
              data: {
                webinarName: webinar.title,
                date: webinar.date,
                time: webinar.time,
                amount: 0,
              },
            },
          });
        } catch (emailError) {
          console.error("Failed to send email:", emailError);
        }

        toast.success("Successfully registered!", {
          description: `You've been registered for "${webinar.title}". Check your email for details.`,
        });
      } catch (error) {
        toast.error("An error occurred. Please try again.");
      }
    }
  };

  const handleMpesaPayment = async () => {
    if (!selectedWebinar || !user) return;

    if (!mpesaPhone || mpesaPhone.length < 10) {
      toast.error("Please enter a valid phone number");
      return;
    }

    setIsProcessing(true);

    try {
      // First save registration as pending
      const { error: regError } = await supabase
        .from("webinar_registrations")
        .insert({
          user_id: user.id,
          webinar_id: selectedWebinar.id,
          webinar_title: selectedWebinar.title,
          webinar_date: selectedWebinar.date,
          webinar_time: selectedWebinar.time,
          format: selectedWebinar.format,
          amount: selectedWebinar.price || 0,
          payment_status: "pending",
        });

      if (regError) {
        console.error("Registration error:", regError);
      }

      const { data, error } = await supabase.functions.invoke('mpesa-stk-push', {
        body: {
          phone: mpesaPhone,
          amount: selectedWebinar.price,
          accountReference: selectedWebinar.title.substring(0, 12),
          transactionDesc: "Webinar Payment",
        },
      });

      if (error) {
        toast.error("Failed to initiate payment. Please try again.");
        setIsProcessing(false);
        return;
      }

      if (data?.success) {
        toast.success("STK Push sent to your phone!", {
          description: "Please enter your M-Pesa PIN to complete payment.",
        });

        // Send email notification
        try {
          await supabase.functions.invoke('send-notification-email', {
            body: {
              type: "webinar_registration",
              to: user.email,
              data: {
                webinarName: selectedWebinar.title,
                date: selectedWebinar.date,
                time: selectedWebinar.time,
                amount: selectedWebinar.price,
              },
            },
          });
        } catch (emailError) {
          console.error("Failed to send email:", emailError);
        }

        setTimeout(() => {
          setIsProcessing(false);
          setShowPaymentModal(false);
          setMpesaPhone("");
          setSelectedWebinar(null);
        }, 3000);
      } else {
        toast.error(data?.message || "Payment failed. Please try again.");
        setIsProcessing(false);
      }
    } catch (error) {
      toast.error("An error occurred. Please try again.");
      setIsProcessing(false);
    }
  };

  const getStatusBadge = (status: Webinar["status"]) => {
    const styles = {
      draft: "bg-gray-100 text-gray-700",
      scheduled: "bg-blue-100 text-blue-700",
      live: "bg-red-100 text-red-700 animate-pulse",
      completed: "bg-green-100 text-green-700",
      cancelled: "bg-red-100 text-red-700",
    };
    return <Badge className={styles[status]}>{status.charAt(0).toUpperCase() + status.slice(1)}</Badge>;
  };

  return (
    <Layout>
      {/* Header */}
      <section className="hero-gradient py-16 lg:py-24">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl lg:text-5xl font-bold text-primary-foreground mb-4">
            Welcome to Our Webinars
          </h1>
          <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto">
            Join our expert-led sessions and enhance your skills from anywhere in the world
          </p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-card border-b border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-4xl font-bold text-primary">{upcomingWebinars.length}</CardTitle>
                <CardDescription className="text-lg">Upcoming Events</CardDescription>
              </CardHeader>
            </Card>
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-4xl font-bold text-primary">{completedWebinars.length}</CardTitle>
                <CardDescription className="text-lg">Completed Events</CardDescription>
              </CardHeader>
            </Card>
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-4xl font-bold text-primary">{totalParticipants.toLocaleString()}</CardTitle>
                <CardDescription className="text-lg">Participants Attended</CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Filters Section */}
      <section className="py-8 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-4 items-end">
            <div className="flex-1">
              <Label className="text-sm font-medium mb-2 block">Search</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  placeholder="Search topics, subjects..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="w-full md:w-48">
              <Label className="text-sm font-medium mb-2 block">Format</Label>
              <Select value={formatFilter} onValueChange={setFormatFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All Formats" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Formats</SelectItem>
                  <SelectItem value="free">Free</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="w-full md:w-48">
              <Label className="text-sm font-medium mb-2 block">Status</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="live">Live</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button 
              onClick={() => {
                setSearchQuery("");
                setFormatFilter("all");
                setStatusFilter("all");
              }}
              variant="outline"
            >
              Reset
            </Button>
          </div>
        </div>
      </section>

      {/* Webinars Grid */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <p className="text-muted-foreground mb-6">
            Showing {filteredWebinars.length} webinars
          </p>
          
          {filteredWebinars.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredWebinars.map((webinar) => (
                <Card key={webinar.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="relative">
                    <img
                      src={webinar.image}
                      alt={webinar.title}
                      className="w-full h-48 object-cover"
                    />
                    <div className="absolute top-3 left-3 flex gap-2">
                      {getStatusBadge(webinar.status)}
                      <Badge variant={webinar.format === "free" ? "secondary" : "default"}>
                        {webinar.format === "free" ? "Free" : `KES ${webinar.price?.toLocaleString()}`}
                      </Badge>
                    </div>
                  </div>
                  <CardContent className="p-5">
                    <h3 className="font-semibold text-lg mb-2">{webinar.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{webinar.description}</p>
                    
                    <div className="space-y-2 text-sm text-muted-foreground mb-4">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span>{new Date(webinar.date).toLocaleDateString('en-US', { dateStyle: 'medium' })}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        <span>{webinar.time} • {webinar.duration}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        <span>{webinar.participants} registered</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Video className="w-4 h-4" />
                        <span>{webinar.instructor}</span>
                      </div>
                    </div>
                    
                    <Badge variant="outline" className="mb-4">{webinar.category}</Badge>
                    
                    <Button 
                      onClick={() => handleRegister(webinar)}
                      disabled={webinar.status === "completed" || webinar.status === "cancelled"}
                      className="w-full hero-gradient border-0 hover:opacity-90"
                    >
                      {webinar.status === "completed" ? "View Recording" : 
                       webinar.status === "live" ? "Join Now" : "Register"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <p className="text-xl text-muted-foreground">No webinars found</p>
              <p className="text-sm text-muted-foreground mt-2">
                Try adjusting your search or filters
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Payment Modal for Paid Webinars */}
      <Dialog open={showPaymentModal} onOpenChange={setShowPaymentModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-green-600" />
              Pay with M-Pesa
            </DialogTitle>
          </DialogHeader>
          
          {selectedWebinar && (
            <div className="space-y-4">
              <div className="p-4 bg-muted rounded-lg">
                <h4 className="font-semibold">{selectedWebinar.title}</h4>
                <p className="text-sm text-muted-foreground">{selectedWebinar.date} at {selectedWebinar.time}</p>
                <p className="text-lg font-bold text-primary mt-2">
                  KES {selectedWebinar.price?.toLocaleString()}
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">M-Pesa Phone Number</Label>
                <Input
                  id="phone"
                  placeholder="0712345678"
                  value={mpesaPhone}
                  onChange={(e) => setMpesaPhone(e.target.value.replace(/\D/g, "").slice(0, 12))}
                />
              </div>

              <div className="p-3 bg-green-50 dark:bg-green-950 rounded-lg border border-green-200 dark:border-green-800">
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5" />
                  <p className="text-sm text-green-700 dark:text-green-300">
                    You will receive an STK Push notification. Enter your M-Pesa PIN to complete payment.
                  </p>
                </div>
              </div>

              <Button
                onClick={handleMpesaPayment}
                disabled={isProcessing}
                className="w-full hero-gradient border-0"
              >
                {isProcessing ? (
                  <span className="flex items-center gap-2">
                    <span className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                    Processing...
                  </span>
                ) : (
                  `Pay KES ${selectedWebinar.price?.toLocaleString()}`
                )}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default Webinars;
