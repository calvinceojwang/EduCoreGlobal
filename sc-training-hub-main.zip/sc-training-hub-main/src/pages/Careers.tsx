import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { MapPin, Clock, Users, ArrowRight, Briefcase, TrendingUp, Heart, Coffee } from "lucide-react";

const openings = [
  {
    id: 1,
    title: "Senior Software Instructor",
    department: "Training",
    location: "Nairobi, Kenya",
    type: "Full-time",
    description: "Lead programming and software development courses for our students.",
  },
  {
    id: 2,
    title: "Finance & Accounting Trainer",
    department: "Training",
    location: "Nairobi, Kenya",
    type: "Full-time",
    description: "Deliver CPA and financial management training programs.",
  },
  {
    id: 3,
    title: "Student Success Manager",
    department: "Operations",
    location: "Nairobi, Kenya",
    type: "Full-time",
    description: "Ensure students have an excellent learning experience from enrollment to certification.",
  },
  {
    id: 4,
    title: "Marketing Specialist",
    department: "Marketing",
    location: "Remote",
    type: "Full-time",
    description: "Drive awareness and enrollment through digital marketing initiatives.",
  },
];

const benefits = [
  { icon: TrendingUp, title: "Career Growth", description: "Clear paths for advancement" },
  { icon: Heart, title: "Health Insurance", description: "Comprehensive medical cover" },
  { icon: Coffee, title: "Work-Life Balance", description: "Flexible working hours" },
  { icon: Briefcase, title: "Learning Budget", description: "Annual training allowance" },
];

const Careers = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="hero-gradient py-20 lg:py-32">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl lg:text-6xl font-bold text-primary-foreground mb-6">
            Join Our Team
          </h1>
          <p className="text-xl text-primary-foreground/80 max-w-3xl mx-auto mb-8">
            Help us shape the future of professional education in Africa
          </p>
          <Button size="lg" className="bg-white text-primary hover:bg-white/90">
            View Open Positions
          </Button>
        </div>
      </section>

      {/* Why Join Us */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl lg:text-4xl font-bold text-center mb-4">Why Work With Us?</h2>
          <p className="text-muted-foreground text-center mb-12 max-w-2xl mx-auto">
            At SC Hosting, we believe in investing in our team as much as our students
          </p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit) => (
              <div key={benefit.title} className="p-6 bg-card rounded-2xl card-shadow text-center">
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <benefit.icon className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">{benefit.title}</h3>
                <p className="text-sm text-muted-foreground">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Open Positions */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl lg:text-4xl font-bold text-center mb-12">Open Positions</h2>
          <div className="max-w-3xl mx-auto space-y-4">
            {openings.map((job) => (
              <div
                key={job.id}
                className="p-6 bg-card rounded-2xl card-shadow hover:card-shadow-hover transition-all group cursor-pointer"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="text-xl font-semibold group-hover:text-primary transition-colors">
                      {job.title}
                    </h3>
                    <p className="text-muted-foreground mt-1">{job.description}</p>
                    <div className="flex flex-wrap gap-4 mt-3 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Briefcase className="w-4 h-4" />
                        {job.department}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {job.location}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {job.type}
                      </span>
                    </div>
                  </div>
                  <Button className="hero-gradient border-0 gap-2 group/btn flex-shrink-0">
                    Apply Now
                    <ArrowRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-1" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Don't See the Right Role?</h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            We're always looking for talented individuals. Send us your resume and we'll keep you in mind for future opportunities.
          </p>
          <Link to="/contact">
            <Button size="lg" variant="outline">
              Send Your Resume
            </Button>
          </Link>
        </div>
      </section>
    </Layout>
  );
};

export default Careers;
