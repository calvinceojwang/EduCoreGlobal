import { Layout } from "@/components/layout/Layout";
import { Link } from "react-router-dom";
import { Calendar, ArrowRight, Clock, User } from "lucide-react";

const posts = [
  {
    id: 1,
    title: "Top 10 IT Certifications for 2025",
    excerpt: "Discover the most in-demand tech certifications that can boost your career in the coming year.",
    image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600&h=400&fit=crop",
    category: "Career Tips",
    author: "James Ochieng",
    date: "Dec 5, 2024",
    readTime: "5 min read",
  },
  {
    id: 2,
    title: "Why Financial Literacy Matters for Tech Professionals",
    excerpt: "Understanding finance can help tech professionals make better career and investment decisions.",
    image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=600&h=400&fit=crop",
    category: "Finance",
    author: "Grace Wanjiku",
    date: "Dec 3, 2024",
    readTime: "4 min read",
  },
  {
    id: 3,
    title: "How to Transition into Cloud Computing",
    excerpt: "A step-by-step guide to building a career in cloud computing, from scratch.",
    image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600&h=400&fit=crop",
    category: "Cloud",
    author: "Peter Mwangi",
    date: "Nov 28, 2024",
    readTime: "6 min read",
  },
  {
    id: 4,
    title: "The Future of Remote Learning in Africa",
    excerpt: "How virtual training is transforming professional education across the continent.",
    image: "https://images.unsplash.com/photo-1588702547919-26089e690ecc?w=600&h=400&fit=crop",
    category: "Education",
    author: "Dr. Sarah Kimani",
    date: "Nov 25, 2024",
    readTime: "5 min read",
  },
  {
    id: 5,
    title: "Essential Skills for Project Managers in 2025",
    excerpt: "Beyond PMP certification: the soft skills that set great project managers apart.",
    image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop",
    category: "Management",
    author: "James Ochieng",
    date: "Nov 20, 2024",
    readTime: "4 min read",
  },
  {
    id: 6,
    title: "Data Science vs Machine Learning: Career Paths",
    excerpt: "Understanding the differences and choosing the right path for your career goals.",
    image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=600&h=400&fit=crop",
    category: "Data Science",
    author: "Peter Mwangi",
    date: "Nov 15, 2024",
    readTime: "7 min read",
  },
];

const Blog = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="hero-gradient py-16 lg:py-24">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl lg:text-5xl font-bold text-primary-foreground mb-4">
            Blog & Resources
          </h1>
          <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto">
            Insights, tips, and guides to help you advance your professional career
          </p>
        </div>
      </section>

      {/* Featured Post */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-8 bg-card rounded-3xl overflow-hidden card-shadow">
            <div className="aspect-video lg:aspect-auto">
              <img
                src={posts[0].image}
                alt={posts[0].title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-8 lg:p-12 flex flex-col justify-center">
              <span className="text-sm font-medium text-primary mb-3">{posts[0].category}</span>
              <h2 className="text-2xl lg:text-3xl font-bold mb-4">{posts[0].title}</h2>
              <p className="text-muted-foreground mb-6">{posts[0].excerpt}</p>
              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-6">
                <span className="flex items-center gap-1">
                  <User className="w-4 h-4" />
                  {posts[0].author}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  {posts[0].date}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {posts[0].readTime}
                </span>
              </div>
              <Link
                to="#"
                className="inline-flex items-center gap-2 text-primary font-medium hover:gap-3 transition-all"
              >
                Read More <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Blog Grid */}
      <section className="py-12 pb-20">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold mb-8">Latest Articles</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {posts.slice(1).map((post) => (
              <article
                key={post.id}
                className="group bg-card rounded-2xl overflow-hidden card-shadow hover:card-shadow-hover transition-all hover:-translate-y-1"
              >
                <div className="aspect-video overflow-hidden">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
                <div className="p-6">
                  <span className="text-xs font-medium text-primary">{post.category}</span>
                  <h3 className="text-lg font-semibold mt-2 mb-3 group-hover:text-primary transition-colors">
                    {post.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                    {post.excerpt}
                  </p>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{post.author}</span>
                    <span>{post.date}</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Blog;
