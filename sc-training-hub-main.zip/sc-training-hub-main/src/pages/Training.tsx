import { useState, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { CourseCard } from "@/components/training/CourseCard";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Filter } from "lucide-react";

const allCourses = [
  // Quality Assurance
  { id: "1", title: "Software Testing Fundamentals", category: "Quality Assurance", duration: "5 Days", price: 42000, image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600&h=400&fit=crop", rating: 4.8, students: 1560, level: "Intermediate" },
  { id: "2", title: "Automated Testing with Selenium", category: "Quality Assurance", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=600&h=400&fit=crop", rating: 4.7, students: 1340, level: "Advanced" },
  { id: "3", title: "Performance Testing Mastery", category: "Quality Assurance", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop", rating: 4.9, students: 980, level: "Advanced" },

  // Governance and Ethics
  { id: "4", title: "Corporate Governance Essentials", category: "Governance and Ethics", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&h=400&fit=crop", rating: 4.8, students: 1450, level: "Intermediate" },
  { id: "5", title: "Business Ethics & Compliance", category: "Governance and Ethics", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=600&h=400&fit=crop", rating: 4.6, students: 1230, level: "Intermediate" },
  { id: "6", title: "Anti-Corruption & Fraud Prevention", category: "Governance and Ethics", duration: "5 Days", price: 58000, image: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=600&h=400&fit=crop", rating: 4.9, students: 890, level: "Advanced" },

  // Strategic Planning
  { id: "7", title: "Strategic Management Masterclass", category: "Strategic Planning", duration: "5 Days", price: 68000, image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop", rating: 4.8, students: 1670, level: "Advanced" },
  { id: "8", title: "Business Strategy Development", category: "Strategic Planning", duration: "5 Days", price: 62000, image: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=600&h=400&fit=crop", rating: 4.7, students: 1450, level: "Intermediate" },
  { id: "9", title: "Scenario Planning & Forecasting", category: "Strategic Planning", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop", rating: 4.6, students: 1120, level: "Advanced" },

  // Data Science
  { id: "10", title: "Data Science with Python", category: "Data Science", duration: "5 Days", price: 58000, image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop", rating: 4.9, students: 2340, level: "Intermediate" },
  { id: "11", title: "Machine Learning Fundamentals", category: "Data Science", duration: "5 Days", price: 62000, image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=600&h=400&fit=crop", rating: 4.8, students: 1980, level: "Intermediate" },
  { id: "12", title: "Deep Learning with TensorFlow", category: "Data Science", duration: "5 Days", price: 65000, image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=600&h=400&fit=crop", rating: 4.9, students: 1560, level: "Advanced" },

  // M&E (Monitoring & Evaluation)
  { id: "13", title: "M&E Framework Development", category: "M&E", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop", rating: 4.7, students: 1340, level: "Intermediate" },
  { id: "14", title: "Results-Based Monitoring", category: "M&E", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop", rating: 4.6, students: 1120, level: "Intermediate" },
  { id: "15", title: "Impact Evaluation Methods", category: "M&E", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1543286386-713bdd548da4?w=600&h=400&fit=crop", rating: 4.8, students: 980, level: "Advanced" },

  // Water and Sanitation
  { id: "16", title: "Water Resource Management", category: "Water and Sanitation", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&h=400&fit=crop", rating: 4.7, students: 890, level: "Intermediate" },
  { id: "17", title: "WASH Project Planning", category: "Water and Sanitation", duration: "5 Days", price: 45000, image: "https://images.unsplash.com/photo-1504197832061-98356e3dcdcf?w=600&h=400&fit=crop", rating: 4.6, students: 750, level: "Intermediate" },

  // Project Management
  { id: "18", title: "Project Management Professional (PMP)", category: "Project Management", duration: "5 Days", price: 70000, image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop", rating: 4.9, students: 2890, level: "Advanced" },
  { id: "19", title: "Agile & Scrum Mastery", category: "Project Management", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=600&h=400&fit=crop", rating: 4.8, students: 2340, level: "Intermediate" },
  { id: "20", title: "PRINCE2 Certification Prep", category: "Project Management", duration: "5 Days", price: 62000, image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&h=400&fit=crop", rating: 4.7, students: 1670, level: "Advanced" },

  // Agribusiness
  { id: "21", title: "Agricultural Value Chains", category: "Agribusiness", duration: "5 Days", price: 45000, image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&h=400&fit=crop", rating: 4.6, students: 1120, level: "Intermediate" },
  { id: "22", title: "Agribusiness Finance", category: "Agribusiness", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1560493676-04071c5f467b?w=600&h=400&fit=crop", rating: 4.7, students: 980, level: "Advanced" },
  { id: "23", title: "Farm Business Management", category: "Agribusiness", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=600&h=400&fit=crop", rating: 4.5, students: 850, level: "Intermediate" },

  // Agriculture
  { id: "24", title: "Modern Farming Techniques", category: "Agriculture", duration: "5 Days", price: 42000, image: "https://images.unsplash.com/photo-1560493676-04071c5f467b?w=600&h=400&fit=crop", rating: 4.6, students: 1340, level: "Intermediate" },
  { id: "25", title: "Sustainable Agriculture Practices", category: "Agriculture", duration: "5 Days", price: 45000, image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&h=400&fit=crop", rating: 4.7, students: 1120, level: "Intermediate" },
  { id: "26", title: "Crop Science & Production", category: "Agriculture", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=600&h=400&fit=crop", rating: 4.5, students: 980, level: "Advanced" },

  // Soft Skills
  { id: "27", title: "Communication & Presentation Skills", category: "Soft Skills", duration: "5 Days", price: 38000, image: "https://images.unsplash.com/photo-1556745757-8d76bdb6984b?w=600&h=400&fit=crop", rating: 4.8, students: 2890, level: "Intermediate" },
  { id: "28", title: "Emotional Intelligence at Work", category: "Soft Skills", duration: "5 Days", price: 42000, image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop", rating: 4.7, students: 1670, level: "Intermediate" },
  { id: "29", title: "Time Management & Productivity", category: "Soft Skills", duration: "5 Days", price: 35000, image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&h=400&fit=crop", rating: 4.9, students: 2340, level: "Intermediate" },

  // Human Resource
  { id: "30", title: "HR Management Fundamentals", category: "Human Resource", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=600&h=400&fit=crop", rating: 4.7, students: 1890, level: "Intermediate" },
  { id: "31", title: "Talent Acquisition & Recruitment", category: "Human Resource", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1556745757-8d76bdb6984b?w=600&h=400&fit=crop", rating: 4.6, students: 1450, level: "Intermediate" },
  { id: "32", title: "Performance Management Systems", category: "Human Resource", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop", rating: 4.8, students: 1230, level: "Advanced" },

  // Health and Health Systems
  { id: "33", title: "Healthcare Management", category: "Health and Health Systems", duration: "5 Days", price: 58000, image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=600&h=400&fit=crop", rating: 4.8, students: 1120, level: "Advanced" },
  { id: "34", title: "Health Systems Strengthening", category: "Health and Health Systems", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=600&h=400&fit=crop", rating: 4.7, students: 890, level: "Intermediate" },

  // Information Technology
  { id: "35", title: "Full Stack Web Development", category: "Information Technology", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600&h=400&fit=crop", rating: 4.9, students: 2890, level: "Intermediate" },
  { id: "36", title: "Cloud Computing with AWS", category: "Information Technology", duration: "5 Days", price: 58000, image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600&h=400&fit=crop", rating: 4.8, students: 2340, level: "Advanced" },
  { id: "37", title: "Mobile App Development", category: "Information Technology", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=600&h=400&fit=crop", rating: 4.7, students: 1980, level: "Intermediate" },

  // Real Estate
  { id: "38", title: "Real Estate Investment Analysis", category: "Real Estate", duration: "5 Days", price: 62000, image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=600&h=400&fit=crop", rating: 4.7, students: 1340, level: "Advanced" },
  { id: "39", title: "Property Valuation Techniques", category: "Real Estate", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1582407947304-fd86f028f716?w=600&h=400&fit=crop", rating: 4.6, students: 1120, level: "Intermediate" },
  { id: "40", title: "Real Estate Development", category: "Real Estate", duration: "5 Days", price: 68000, image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&h=400&fit=crop", rating: 4.8, students: 980, level: "Advanced" },

  // Data Analytics
  { id: "41", title: "Data Analytics with Power BI", category: "Data Analytics", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop", rating: 4.8, students: 2670, level: "Intermediate" },
  { id: "42", title: "Advanced Excel for Analytics", category: "Data Analytics", duration: "5 Days", price: 38000, image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop", rating: 4.9, students: 3120, level: "Advanced" },
  { id: "43", title: "Statistical Analysis with R", category: "Data Analytics", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1543286386-713bdd548da4?w=600&h=400&fit=crop", rating: 4.7, students: 1890, level: "Advanced" },

  // Business Intelligence
  { id: "44", title: "BI Tools & Dashboards", category: "Business Intelligence", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop", rating: 4.8, students: 1780, level: "Intermediate" },
  { id: "45", title: "Data Visualization Mastery", category: "Business Intelligence", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1543286386-713bdd548da4?w=600&h=400&fit=crop", rating: 4.7, students: 1560, level: "Advanced" },
  { id: "46", title: "Tableau for Business", category: "Business Intelligence", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop", rating: 4.9, students: 1340, level: "Intermediate" },

  // Supply Chain
  { id: "47", title: "Supply Chain Management", category: "Supply Chain", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&h=400&fit=crop", rating: 4.7, students: 1670, level: "Intermediate" },
  { id: "48", title: "Procurement & Sourcing", category: "Supply Chain", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1553413077-190dd305871c?w=600&h=400&fit=crop", rating: 4.6, students: 1340, level: "Intermediate" },
  { id: "49", title: "Inventory Management", category: "Supply Chain", duration: "5 Days", price: 45000, image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&h=400&fit=crop", rating: 4.8, students: 1120, level: "Advanced" },

  // Databases
  { id: "50", title: "SQL & Database Administration", category: "Databases", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=600&h=400&fit=crop", rating: 4.8, students: 1890, level: "Intermediate" },
  { id: "51", title: "MongoDB & NoSQL Databases", category: "Databases", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=600&h=400&fit=crop", rating: 4.7, students: 1450, level: "Advanced" },
  { id: "52", title: "Database Design & Optimization", category: "Databases", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1518186285589-2f7649de83e0?w=600&h=400&fit=crop", rating: 4.6, students: 1120, level: "Advanced" },

  // Humanitarian
  { id: "53", title: "Humanitarian Response", category: "Humanitarian", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1559027615-cd4628902d4a?w=600&h=400&fit=crop", rating: 4.8, students: 1340, level: "Intermediate" },
  { id: "54", title: "Emergency Management", category: "Humanitarian", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?w=600&h=400&fit=crop", rating: 4.7, students: 1120, level: "Advanced" },
  { id: "55", title: "Disaster Risk Reduction", category: "Humanitarian", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1559027615-cd4628902d4a?w=600&h=400&fit=crop", rating: 4.9, students: 980, level: "Advanced" },

  // Business Management
  { id: "56", title: "Business Administration", category: "Business Management", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop", rating: 4.7, students: 2120, level: "Intermediate" },
  { id: "57", title: "Operations Management", category: "Business Management", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&h=400&fit=crop", rating: 4.6, students: 1780, level: "Intermediate" },
  { id: "58", title: "Change Management", category: "Business Management", duration: "5 Days", price: 58000, image: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=600&h=400&fit=crop", rating: 4.8, students: 1450, level: "Advanced" },

  // Leadership
  { id: "59", title: "Executive Leadership Program", category: "Leadership", duration: "5 Days", price: 75000, image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=600&h=400&fit=crop", rating: 4.9, students: 1890, level: "Advanced" },
  { id: "60", title: "Team Leadership & Management", category: "Leadership", duration: "5 Days", price: 58000, image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop", rating: 4.8, students: 2340, level: "Intermediate" },
  { id: "61", title: "Strategic Leadership", category: "Leadership", duration: "5 Days", price: 68000, image: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=600&h=400&fit=crop", rating: 4.7, students: 1560, level: "Advanced" },

  // Data Collection
  { id: "62", title: "Survey Design & Data Collection", category: "Data Collection", duration: "5 Days", price: 42000, image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop", rating: 4.6, students: 1120, level: "Intermediate" },
  { id: "63", title: "Mobile Data Collection Tools", category: "Data Collection", duration: "5 Days", price: 45000, image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=600&h=400&fit=crop", rating: 4.7, students: 980, level: "Intermediate" },

  // Food Security
  { id: "64", title: "Food Security Assessment", category: "Food Security", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=600&h=400&fit=crop", rating: 4.7, students: 890, level: "Intermediate" },
  { id: "65", title: "Nutrition & Food Systems", category: "Food Security", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&h=400&fit=crop", rating: 4.6, students: 750, level: "Advanced" },

  // Cyber Security
  { id: "66", title: "Cybersecurity Fundamentals", category: "Cyber Security", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=600&h=400&fit=crop", rating: 4.9, students: 2120, level: "Intermediate" },
  { id: "67", title: "Ethical Hacking & Penetration Testing", category: "Cyber Security", duration: "5 Days", price: 62000, image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=600&h=400&fit=crop", rating: 4.8, students: 1780, level: "Advanced" },
  { id: "68", title: "Network Security", category: "Cyber Security", duration: "5 Days", price: 58000, image: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=600&h=400&fit=crop", rating: 4.7, students: 1450, level: "Advanced" },

  // ERP Systems
  { id: "69", title: "SAP Fundamentals", category: "ERP Systems", duration: "5 Days", price: 65000, image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=600&h=400&fit=crop", rating: 4.8, students: 1340, level: "Intermediate" },
  { id: "70", title: "Oracle ERP Training", category: "ERP Systems", duration: "5 Days", price: 68000, image: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=600&h=400&fit=crop", rating: 4.7, students: 1120, level: "Advanced" },

  // Logistics and Distribution
  { id: "71", title: "Logistics Management", category: "Logistics and Distribution", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&h=400&fit=crop", rating: 4.7, students: 1560, level: "Intermediate" },
  { id: "72", title: "Warehouse Management", category: "Logistics and Distribution", duration: "5 Days", price: 45000, image: "https://images.unsplash.com/photo-1553413077-190dd305871c?w=600&h=400&fit=crop", rating: 4.6, students: 1230, level: "Intermediate" },
  { id: "73", title: "Transportation & Fleet Management", category: "Logistics and Distribution", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&h=400&fit=crop", rating: 4.8, students: 980, level: "Advanced" },

  // Marketing
  { id: "74", title: "Digital Marketing Mastery", category: "Marketing", duration: "5 Days", price: 42000, image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop", rating: 4.8, students: 2890, level: "Intermediate" },
  { id: "75", title: "Social Media Marketing", category: "Marketing", duration: "5 Days", price: 38000, image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=600&h=400&fit=crop", rating: 4.7, students: 2340, level: "Intermediate" },
  { id: "76", title: "Content Marketing Strategy", category: "Marketing", duration: "5 Days", price: 45000, image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop", rating: 4.6, students: 1780, level: "Advanced" },

  // Risk Management
  { id: "77", title: "Enterprise Risk Management", category: "Risk Management", duration: "5 Days", price: 58000, image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&h=400&fit=crop", rating: 4.8, students: 1450, level: "Advanced" },
  { id: "78", title: "Financial Risk Analysis", category: "Risk Management", duration: "5 Days", price: 62000, image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=600&h=400&fit=crop", rating: 4.7, students: 1230, level: "Advanced" },
  { id: "79", title: "Operational Risk Management", category: "Risk Management", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop", rating: 4.9, students: 1120, level: "Intermediate" },

  // Customer Service
  { id: "80", title: "Customer Service Excellence", category: "Customer Service", duration: "5 Days", price: 35000, image: "https://images.unsplash.com/photo-1556745757-8d76bdb6984b?w=600&h=400&fit=crop", rating: 4.8, students: 2340, level: "Intermediate" },
  { id: "81", title: "Customer Experience Management", category: "Customer Service", duration: "5 Days", price: 42000, image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop", rating: 4.7, students: 1780, level: "Advanced" },
  { id: "82", title: "Call Center Management", category: "Customer Service", duration: "5 Days", price: 38000, image: "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=600&h=400&fit=crop", rating: 4.6, students: 1340, level: "Intermediate" },

  // Research
  { id: "83", title: "Research Methods & Design", category: "Research", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop", rating: 4.7, students: 1450, level: "Intermediate" },
  { id: "84", title: "Qualitative Research Techniques", category: "Research", duration: "5 Days", price: 45000, image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop", rating: 4.6, students: 1120, level: "Intermediate" },
  { id: "85", title: "Statistical Research Analysis", category: "Research", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1543286386-713bdd548da4?w=600&h=400&fit=crop", rating: 4.8, students: 980, level: "Advanced" },

  // Finance
  { id: "86", title: "Financial Management", category: "Finance", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=600&h=400&fit=crop", rating: 4.8, students: 2120, level: "Intermediate" },
  { id: "87", title: "Investment Analysis", category: "Finance", duration: "5 Days", price: 62000, image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=600&h=400&fit=crop", rating: 4.9, students: 1780, level: "Advanced" },
  { id: "88", title: "Financial Modeling in Excel", category: "Finance", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop", rating: 4.7, students: 2340, level: "Advanced" },

  // Auditing
  { id: "89", title: "Internal Audit Fundamentals", category: "Auditing", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&h=400&fit=crop", rating: 4.7, students: 1340, level: "Intermediate" },
  { id: "90", title: "IT Audit & Assurance", category: "Auditing", duration: "5 Days", price: 58000, image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=600&h=400&fit=crop", rating: 4.8, students: 1120, level: "Advanced" },
  { id: "91", title: "Forensic Auditing", category: "Auditing", duration: "5 Days", price: 62000, image: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=600&h=400&fit=crop", rating: 4.9, students: 890, level: "Advanced" },

  // Tooling
  { id: "92", title: "Microsoft Office Suite Advanced", category: "Tooling", duration: "5 Days", price: 35000, image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop", rating: 4.8, students: 3120, level: "Advanced" },
  { id: "93", title: "Google Workspace Mastery", category: "Tooling", duration: "5 Days", price: 32000, image: "https://images.unsplash.com/photo-1573164713988-8665fc963095?w=600&h=400&fit=crop", rating: 4.7, students: 2560, level: "Intermediate" },
  { id: "94", title: "Productivity Tools & Automation", category: "Tooling", duration: "5 Days", price: 38000, image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=600&h=400&fit=crop", rating: 4.6, students: 1890, level: "Intermediate" },

  // Data Engineering
  { id: "95", title: "Data Engineering with Python", category: "Data Engineering", duration: "5 Days", price: 58000, image: "https://images.unsplash.com/photo-1518186285589-2f7649de83e0?w=600&h=400&fit=crop", rating: 4.8, students: 1560, level: "Advanced" },
  { id: "96", title: "ETL & Data Pipelines", category: "Data Engineering", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop", rating: 4.7, students: 1340, level: "Advanced" },
  { id: "97", title: "Big Data Technologies", category: "Data Engineering", duration: "5 Days", price: 62000, image: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=600&h=400&fit=crop", rating: 4.9, students: 1120, level: "Advanced" },

  // Insurance
  { id: "98", title: "Insurance Principles & Practices", category: "Insurance", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=600&h=400&fit=crop", rating: 4.6, students: 890, level: "Intermediate" },
  { id: "99", title: "Risk Assessment in Insurance", category: "Insurance", duration: "5 Days", price: 52000, image: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=600&h=400&fit=crop", rating: 4.7, students: 750, level: "Advanced" },

  // GIS
  { id: "100", title: "GIS Fundamentals with QGIS", category: "GIS", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600&h=400&fit=crop", rating: 4.8, students: 1340, level: "Intermediate" },
  { id: "101", title: "Remote Sensing & Spatial Analysis", category: "GIS", duration: "5 Days", price: 55000, image: "https://images.unsplash.com/photo-1573164713988-8665fc963095?w=600&h=400&fit=crop", rating: 4.7, students: 1120, level: "Advanced" },
  { id: "102", title: "ArcGIS Professional", category: "GIS", duration: "5 Days", price: 58000, image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600&h=400&fit=crop", rating: 4.9, students: 980, level: "Advanced" },

  // Sales
  { id: "103", title: "Sales Mastery Program", category: "Sales", duration: "5 Days", price: 42000, image: "https://images.unsplash.com/photo-1556745757-8d76bdb6984b?w=600&h=400&fit=crop", rating: 4.8, students: 2120, level: "Intermediate" },
  { id: "104", title: "B2B Sales Strategies", category: "Sales", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop", rating: 4.7, students: 1670, level: "Advanced" },
  { id: "105", title: "Negotiation & Closing Techniques", category: "Sales", duration: "5 Days", price: 45000, image: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=600&h=400&fit=crop", rating: 4.9, students: 1450, level: "Advanced" },

  // OHS (Occupational Health & Safety)
  { id: "106", title: "Occupational Health & Safety", category: "OHS", duration: "5 Days", price: 45000, image: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=600&h=400&fit=crop", rating: 4.7, students: 1340, level: "Intermediate" },
  { id: "107", title: "Workplace Safety Management", category: "OHS", duration: "5 Days", price: 48000, image: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=600&h=400&fit=crop", rating: 4.6, students: 1120, level: "Intermediate" },
  { id: "108", title: "NEBOSH Certification Prep", category: "OHS", duration: "5 Days", price: 65000, image: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=600&h=400&fit=crop", rating: 4.9, students: 980, level: "Advanced" },
];

const categories = [
  { value: "all", label: "All Categories" },
  { value: "qa", label: "Quality Assurance" },
  { value: "governance", label: "Governance and Ethics" },
  { value: "strategic", label: "Strategic Planning" },
  { value: "datascience", label: "Data Science" },
  { value: "me", label: "M&E" },
  { value: "water", label: "Water and Sanitation" },
  { value: "pm", label: "Project Management" },
  { value: "agribusiness", label: "Agribusiness" },
  { value: "agriculture", label: "Agriculture" },
  { value: "softskills", label: "Soft Skills" },
  { value: "hr", label: "Human Resource" },
  { value: "health", label: "Health and Health Systems" },
  { value: "it", label: "Information Technology" },
  { value: "realestate", label: "Real Estate" },
  { value: "analytics", label: "Data Analytics" },
  { value: "bi", label: "Business Intelligence" },
  { value: "supplychain", label: "Supply Chain" },
  { value: "databases", label: "Databases" },
  { value: "humanitarian", label: "Humanitarian" },
  { value: "businessmgmt", label: "Business Management" },
  { value: "leadership", label: "Leadership" },
  { value: "datacollection", label: "Data Collection" },
  { value: "foodsecurity", label: "Food Security" },
  { value: "cybersecurity", label: "Cyber Security" },
  { value: "erp", label: "ERP Systems" },
  { value: "logistics", label: "Logistics and Distribution" },
  { value: "marketing", label: "Marketing" },
  { value: "risk", label: "Risk Management" },
  { value: "customerservice", label: "Customer Service" },
  { value: "research", label: "Research" },
  { value: "finance", label: "Finance" },
  { value: "auditing", label: "Auditing" },
  { value: "tooling", label: "Tooling" },
  { value: "dataengineering", label: "Data Engineering" },
  { value: "insurance", label: "Insurance" },
  { value: "gis", label: "GIS" },
  { value: "sales", label: "Sales" },
  { value: "ohs", label: "OHS" },
];

const categoryMap: Record<string, string> = {
  qa: "Quality Assurance",
  governance: "Governance and Ethics",
  strategic: "Strategic Planning",
  datascience: "Data Science",
  me: "M&E",
  water: "Water and Sanitation",
  pm: "Project Management",
  agribusiness: "Agribusiness",
  agriculture: "Agriculture",
  softskills: "Soft Skills",
  hr: "Human Resource",
  health: "Health and Health Systems",
  it: "Information Technology",
  realestate: "Real Estate",
  analytics: "Data Analytics",
  bi: "Business Intelligence",
  supplychain: "Supply Chain",
  databases: "Databases",
  humanitarian: "Humanitarian",
  businessmgmt: "Business Management",
  leadership: "Leadership",
  datacollection: "Data Collection",
  foodsecurity: "Food Security",
  cybersecurity: "Cyber Security",
  erp: "ERP Systems",
  logistics: "Logistics and Distribution",
  marketing: "Marketing",
  risk: "Risk Management",
  customerservice: "Customer Service",
  research: "Research",
  finance: "Finance",
  auditing: "Auditing",
  tooling: "Tooling",
  dataengineering: "Data Engineering",
  insurance: "Insurance",
  gis: "GIS",
  sales: "Sales",
  ohs: "OHS",
};

const Training = () => {
  const [searchParams] = useSearchParams();
  const initialCategory = searchParams.get("category") || "all";
  
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState(initialCategory);
  const [sortBy, setSortBy] = useState("popular");

  const filteredCourses = useMemo(() => {
    let courses = [...allCourses];
    
    // Filter by search
    if (search) {
      courses = courses.filter((c) =>
        c.title.toLowerCase().includes(search.toLowerCase()) ||
        c.category.toLowerCase().includes(search.toLowerCase())
      );
    }
    
    // Filter by category
    if (category !== "all") {
      const categoryName = categoryMap[category];
      if (categoryName) {
        courses = courses.filter((c) => c.category === categoryName);
      }
    }
    
    // Sort
    switch (sortBy) {
      case "price-low":
        courses.sort((a, b) => a.price - b.price);
        break;
      case "price-high":
        courses.sort((a, b) => b.price - a.price);
        break;
      case "rating":
        courses.sort((a, b) => b.rating - a.rating);
        break;
      default:
        courses.sort((a, b) => b.students - a.students);
    }
    
    return courses;
  }, [search, category, sortBy]);

  return (
    <Layout>
      {/* Header */}
      <section className="relative hero-gradient py-16 lg:py-24 overflow-hidden">
        {/* Background Video */}
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover opacity-30"
        >
          <source
            src="https://videos.pexels.com/video-files/3195394/3195394-uhd_2560_1440_25fps.mp4"
            type="video/mp4"
          />
        </video>
        {/* Overlay for better text readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-primary/40 to-primary/60" />
        
        <div className="container mx-auto px-4 text-center relative z-10">
          <h1 className="text-3xl lg:text-5xl font-bold text-primary-foreground mb-4">
            Our Training Programs
          </h1>
          <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto">
            Explore our comprehensive catalog of professional courses and certifications
          </p>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-card border-b border-border sticky top-16 lg:top-20 z-40">
        <div className="container mx-auto px-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search courses..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="sm:w-56">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat.value} value={cat.value}>
                    {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="sm:w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popular">Most Popular</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      {/* Courses Grid */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <p className="text-muted-foreground mb-6">
            Showing {filteredCourses.length} courses
          </p>
          
          {filteredCourses.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
              {filteredCourses.map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <p className="text-xl text-muted-foreground">No courses found</p>
              <p className="text-sm text-muted-foreground mt-2">
                Try adjusting your search or filters
              </p>
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
};

export default Training;
