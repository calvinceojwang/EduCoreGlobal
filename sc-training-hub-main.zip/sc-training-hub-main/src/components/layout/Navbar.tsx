import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, X, GraduationCap, User, ChevronDown, MapPin, LayoutDashboard, LogOut } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const navLinks = [
  { name: "Home", path: "/" },
  { name: "Training", path: "/training" },
  { name: "Webinars", path: "/webinars" },
  { name: "About Us", path: "/about" },
  { name: "Careers", path: "/careers" },
  { name: "Blog", path: "/blog" },
  { name: "Contact", path: "/contact" },
  { name: "Support", path: "/support" },
];

const trainingDestinations = [
  { name: "Virtual (Zoom)", code: "virtual" },
  { name: "Nairobi, Kenya", code: "nairobi-ke" },
  { name: "Kigali, Rwanda", code: "kigali-rw" },
  { name: "Dubai, UAE", code: "dubai-uae" },
  { name: "Kampala, Uganda", code: "kampala-ug" },
  { name: "Zanzibar, Tanzania", code: "zanzibar-tz" },
  { name: "Mombasa, Kenya", code: "mombasa-ke" },
  { name: "Johannesburg, South Africa", code: "johannesburg-za" },
  { name: "Cape Town, South Africa", code: "capetown-za" },
  { name: "Pretoria, South Africa", code: "pretoria-za" },
  { name: "Naivasha, Kenya", code: "naivasha-ke" },
  { name: "Nakuru, Kenya", code: "nakuru-ke" },
  { name: "Kisumu, Kenya", code: "kisumu-ke" },
  { name: "Kuala Lumpur, Malaysia", code: "kualalumpur-my" },
  { name: "Jeddah, KSA", code: "jeddah-sa" },
  { name: "Dar es Salaam, Tanzania", code: "dar-tz" },
  { name: "Singapore", code: "singapore-sg" },
  { name: "Arusha, Tanzania", code: "arusha-tz" },
  { name: "Lagos, Nigeria", code: "lagos-ng" },
  { name: "Abuja, Nigeria", code: "abuja-ng" },
  { name: "Accra, Ghana", code: "accra-gh" },
  { name: "Riyadh, Saudi Arabia", code: "riyadh-sa" },
];

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [mobileDestinationsOpen, setMobileDestinationsOpen] = useState(false);
  const location = useLocation();
  const { user, signOut } = useAuth();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-border/50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 rounded-xl hero-gradient flex items-center justify-center transition-transform group-hover:scale-105">
              <GraduationCap className="w-6 h-6 text-primary-foreground" />
            </div>
            <div className="hidden sm:block">
              <span className="font-bold text-lg text-foreground">SC Hosting</span>
              <span className="block text-xs text-muted-foreground -mt-1">Training Hub</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={cn(
                  "px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200",
                  location.pathname === link.path
                    ? "text-primary bg-primary/10"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                )}
              >
                {link.name}
              </Link>
            ))}
            
            {/* Training Destinations Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 text-muted-foreground hover:text-foreground hover:bg-muted flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  Destinations
                  <ChevronDown className="w-4 h-4" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-64 max-h-96 overflow-y-auto bg-background">
                {trainingDestinations.map((dest) => (
                  <DropdownMenuItem
                    key={dest.code}
                    asChild
                    className="cursor-pointer hover:bg-primary/10 hover:text-primary transition-colors"
                  >
                    <Link to={`/destinations/${dest.code}`} className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      {dest.name}
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Auth Buttons */}
          <div className="hidden lg:flex items-center gap-3">
            {user ? (
              <>
                <Link to="/dashboard">
                  <Button variant="ghost" size="sm" className="gap-2">
                    <LayoutDashboard className="w-4 h-4" />
                    Dashboard
                  </Button>
                </Link>
                <Button variant="ghost" size="sm" className="gap-2" onClick={signOut}>
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </Button>
              </>
            ) : (
              <>
                <Link to="/login">
                  <Button variant="ghost" size="sm" className="gap-2">
                    <User className="w-4 h-4" />
                    Sign In
                  </Button>
                </Link>
                <Link to="/register">
                  <Button size="sm" className="hero-gradient border-0 hover:opacity-90 transition-opacity">
                    Get Started
                  </Button>
                </Link>
              </>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden p-2 rounded-lg hover:bg-muted transition-colors"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="lg:hidden py-4 border-t border-border/50 animate-slide-in max-h-[80vh] overflow-y-auto">
            <div className="flex flex-col gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={cn(
                    "px-4 py-3 rounded-lg text-sm font-medium transition-colors",
                    location.pathname === link.path
                      ? "text-primary bg-primary/10"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted"
                  )}
                >
                  {link.name}
                </Link>
              ))}
              
              {/* Mobile Destinations */}
              <button
                onClick={() => setMobileDestinationsOpen(!mobileDestinationsOpen)}
                className="px-4 py-3 rounded-lg text-sm font-medium transition-colors text-muted-foreground hover:text-foreground hover:bg-muted flex items-center justify-between"
              >
                <span className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Training Destinations
                </span>
                <ChevronDown className={cn("w-4 h-4 transition-transform", mobileDestinationsOpen && "rotate-180")} />
              </button>
              
              {mobileDestinationsOpen && (
                <div className="pl-4 space-y-1">
                  {trainingDestinations.map((dest) => (
                    <Link
                      key={dest.code}
                      to={`/destinations/${dest.code}`}
                      onClick={() => setIsOpen(false)}
                      className="block px-4 py-2 rounded-lg text-sm text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
                    >
                      {dest.name}
                    </Link>
                  ))}
                </div>
              )}
              
              <div className="flex flex-col gap-2 mt-4 px-4">
                {user ? (
                  <>
                    <Link to="/dashboard" className="w-full" onClick={() => setIsOpen(false)}>
                      <Button variant="outline" className="w-full gap-2">
                        <LayoutDashboard className="w-4 h-4" />
                        Dashboard
                      </Button>
                    </Link>
                    <Button className="w-full gap-2" variant="outline" onClick={() => { signOut(); setIsOpen(false); }}>
                      <LogOut className="w-4 h-4" />
                      Sign Out
                    </Button>
                  </>
                ) : (
                  <div className="flex gap-2">
                    <Link to="/login" className="flex-1" onClick={() => setIsOpen(false)}>
                      <Button variant="outline" className="w-full">Sign In</Button>
                    </Link>
                    <Link to="/register" className="flex-1" onClick={() => setIsOpen(false)}>
                      <Button className="w-full hero-gradient border-0">Get Started</Button>
                    </Link>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
