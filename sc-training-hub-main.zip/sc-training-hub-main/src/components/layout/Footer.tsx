import { Link } from "react-router-dom";
import { GraduationCap, Mail, Phone, MapPin, Facebook, Twitter, Linkedin, Instagram } from "lucide-react";

const footerLinks = {
  training: [
    { name: "Computer Science", path: "/training?category=cs" },
    { name: "Finance & Accounting", path: "/training?category=finance" },
    { name: "Professional Certifications", path: "/training?category=certifications" },
    { name: "All Courses", path: "/training" },
  ],
  company: [
    { name: "About Us", path: "/about" },
    { name: "Careers", path: "/careers" },
    { name: "Blog", path: "/blog" },
    { name: "Contact", path: "/contact" },
  ],
  support: [
    { name: "Help Center", path: "/support" },
    { name: "Terms of Service", path: "/terms" },
    { name: "Privacy Policy", path: "/privacy" },
    { name: "FAQ", path: "/support#faq" },
  ],
};

export function Footer() {
  return (
    <footer className="bg-foreground text-primary-foreground">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="space-y-6">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <span className="font-bold text-lg">SC Hosting</span>
                <span className="block text-xs opacity-70 -mt-1">Training Hub</span>
              </div>
            </Link>
            <p className="text-sm opacity-70 leading-relaxed">
              Empowering professionals with world-class training and certifications in technology, finance, and more.
            </p>
            <div className="flex gap-3">
              {[Facebook, Twitter, Linkedin, Instagram].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-10 h-10 rounded-lg bg-primary-foreground/10 flex items-center justify-center hover:bg-primary transition-colors"
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Training */}
          <div>
            <h4 className="font-semibold mb-6">Training</h4>
            <ul className="space-y-3">
              {footerLinks.training.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm opacity-70 hover:opacity-100 transition-opacity"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-semibold mb-6">Company</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm opacity-70 hover:opacity-100 transition-opacity"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold mb-6">Our Locations</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 opacity-70 flex-shrink-0 mt-0.5" />
                <div className="text-sm opacity-70 space-y-1">
                  <p>Kenya • Uganda • Tanzania</p>
                  <p>Rwanda • Zambia • Djibouti</p>
                  <p>Nigeria • Ghana • Dubai</p>
                </div>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 opacity-70" />
                <a href="tel:+254700000000" className="text-sm opacity-70 hover:opacity-100">
                  +254 700 000 000
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 opacity-70" />
                <a href="mailto:info@schosting.co.ke" className="text-sm opacity-70 hover:opacity-100">
                  info@schosting.co.ke
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-foreground/10 mt-12 pt-8 text-center">
          <p className="text-sm opacity-70">
            © {new Date().getFullYear()} SC Hosting Training Hub. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
