import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { Clock, MapPin, Video, Calendar as CalendarIcon, CheckCircle, Users, User } from "lucide-react";
import { format, addDays } from "date-fns";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { PaymentModal } from "./PaymentModal";

interface Course {
  id: string;
  title: string;
  category: string;
  duration: string;
  price: number;
  image: string;
  rating: number;
  students: number;
}

interface BookingModalProps {
  course: Course;
  isOpen: boolean;
  onClose: () => void;
}

const timeSlots = [
  "09:00 AM - 05:00 PM",
  "10:00 AM - 06:00 PM",
  "02:00 PM - 10:00 PM",
];

export function BookingModal({ course, isOpen, onClose }: BookingModalProps) {
  const [date, setDate] = useState<Date | undefined>();
  const [time, setTime] = useState<string>("");
  const [trainingType, setTrainingType] = useState<"physical" | "virtual">("physical");
  const [bookingType, setBookingType] = useState<"individual" | "group">("individual");
  const [participants, setParticipants] = useState<number>(2);
  const [showPayment, setShowPayment] = useState(false);

  const totalAmount = bookingType === "group" ? course.price * participants : course.price;

  const handleProceedToPayment = () => {
    if (!date || !time) {
      toast.error("Please select date and time");
      return;
    }
    if (bookingType === "group" && participants < 2) {
      toast.error("Group booking requires minimum 2 participants");
      return;
    }
    setShowPayment(true);
  };

  const handlePaymentClose = () => {
    setShowPayment(false);
    onClose();
    setDate(undefined);
    setTime("");
    setTrainingType("physical");
    setBookingType("individual");
    setParticipants(2);
  };

  const endDate = date ? addDays(date, 4) : undefined;

  return (
    <>
      <Dialog open={isOpen && !showPayment} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-lg">Book Training</DialogTitle>
          </DialogHeader>

          {/* Course Info - Compact */}
          <div className="flex gap-3 p-3 bg-muted rounded-lg">
            <img
              src={course.image}
              alt={course.title}
              className="w-14 h-14 rounded-lg object-cover"
            />
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-sm truncate">{course.title}</h3>
              <p className="text-xs text-muted-foreground">{course.category}</p>
              <p className="text-base font-bold text-primary">
                KES {course.price.toLocaleString()} / person
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {/* Booking Type Selection */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Booking Type</Label>
              <RadioGroup
                value={bookingType}
                onValueChange={(v) => setBookingType(v as "individual" | "group")}
                className="flex gap-3"
              >
                <div className="flex-1">
                  <RadioGroupItem value="individual" id="individual" className="peer sr-only" />
                  <Label
                    htmlFor="individual"
                    className="flex items-center gap-2 p-3 rounded-lg border-2 cursor-pointer transition-all peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5"
                  >
                    <User className="w-4 h-4 text-primary" />
                    <div>
                      <p className="font-medium text-sm">Individual</p>
                      <p className="text-xs text-muted-foreground">1 person</p>
                    </div>
                  </Label>
                </div>
                <div className="flex-1">
                  <RadioGroupItem value="group" id="group" className="peer sr-only" />
                  <Label
                    htmlFor="group"
                    className="flex items-center gap-2 p-3 rounded-lg border-2 cursor-pointer transition-all peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5"
                  >
                    <Users className="w-4 h-4 text-primary" />
                    <div>
                      <p className="font-medium text-sm">Group</p>
                      <p className="text-xs text-muted-foreground">2+ people</p>
                    </div>
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {/* Participants Count - Only show for group booking */}
            {bookingType === "group" && (
              <div className="space-y-2">
                <Label className="text-sm font-medium">Number of Participants</Label>
                <div className="flex items-center gap-3">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setParticipants(Math.max(2, participants - 1))}
                    disabled={participants <= 2}
                  >
                    -
                  </Button>
                  <Input
                    type="number"
                    min={2}
                    value={participants}
                    onChange={(e) => setParticipants(Math.max(2, parseInt(e.target.value) || 2))}
                    className="w-20 text-center"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setParticipants(participants + 1)}
                  >
                    +
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">Minimum 2 participants for group booking</p>
              </div>
            )}

            {/* Training Type - Compact */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Training Type</Label>
              <RadioGroup
                value={trainingType}
                onValueChange={(v) => setTrainingType(v as "physical" | "virtual")}
                className="flex gap-3"
              >
                <div className="flex-1">
                  <RadioGroupItem value="physical" id="physical" className="peer sr-only" />
                  <Label
                    htmlFor="physical"
                    className="flex items-center gap-2 p-3 rounded-lg border-2 cursor-pointer transition-all peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5"
                  >
                    <MapPin className="w-4 h-4 text-primary" />
                    <div>
                      <p className="font-medium text-sm">Physical</p>
                      <p className="text-xs text-muted-foreground">In-person</p>
                    </div>
                  </Label>
                </div>
                <div className="flex-1">
                  <RadioGroupItem value="virtual" id="virtual" className="peer sr-only" />
                  <Label
                    htmlFor="virtual"
                    className="flex items-center gap-2 p-3 rounded-lg border-2 cursor-pointer transition-all peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5"
                  >
                    <Video className="w-4 h-4 text-primary" />
                    <div>
                      <p className="font-medium text-sm">Virtual</p>
                      <p className="text-xs text-muted-foreground">Via Zoom</p>
                    </div>
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {/* Date Selection - Popover */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Select Start Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    disabled={(date) => date < new Date()}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>

            {/* Time Selection */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Preferred Time</Label>
              <Select value={time} onValueChange={setTime}>
                <SelectTrigger>
                  <SelectValue placeholder="Select time slot" />
                </SelectTrigger>
                <SelectContent>
                  {timeSlots.map((slot) => (
                    <SelectItem key={slot} value={slot}>
                      {slot}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Duration Info - Compact */}
            {date && (
              <div className="p-3 bg-primary/5 rounded-lg space-y-1 text-sm">
                <div className="flex items-center gap-2">
                  <CalendarIcon className="w-4 h-4 text-primary" />
                  <span className="font-medium">5 Days Training</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  <span>{format(date, "MMM d")} - {format(endDate!, "MMM d, yyyy")}</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <CheckCircle className="w-4 h-4" />
                  <span>{trainingType === "physical" ? "In-person training" : "Virtual via Zoom"}</span>
                </div>
                {bookingType === "group" && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Users className="w-4 h-4" />
                    <span>{participants} participants</span>
                  </div>
                )}
              </div>
            )}

            {/* Total Amount Display */}
            {bookingType === "group" && (
              <div className="p-3 bg-accent/10 rounded-lg border border-accent/20">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Price per person:</span>
                  <span className="font-medium">KES {course.price.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Participants:</span>
                  <span className="font-medium">{participants}</span>
                </div>
                <div className="border-t border-border mt-2 pt-2 flex justify-between items-center">
                  <span className="font-semibold">Total Amount:</span>
                  <span className="text-lg font-bold text-primary">KES {totalAmount.toLocaleString()}</span>
                </div>
              </div>
            )}

            {/* Proceed to Payment Button */}
            <Button
              onClick={handleProceedToPayment}
              disabled={!date || !time}
              className="w-full hero-gradient border-0 hover:opacity-90"
              size="lg"
            >
              Proceed to Payment - KES {totalAmount.toLocaleString()}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Payment Modal */}
      <PaymentModal
        isOpen={showPayment}
        onClose={handlePaymentClose}
        courseTitle={course.title}
        amount={totalAmount}
        bookingDetails={{
          date: date ? format(date, "PPP") : "",
          time: time,
          type: trainingType === "physical" ? "Physical (In-person)" : "Virtual (Zoom)",
          bookingType: bookingType === "group" ? `Group (${participants} participants)` : "Individual",
        }}
      />
    </>
  );
}
