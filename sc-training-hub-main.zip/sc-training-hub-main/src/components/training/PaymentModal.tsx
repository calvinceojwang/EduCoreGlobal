import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { CreditCard, Smartphone, Lock, CheckCircle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  courseTitle: string;
  amount: number;
  bookingDetails: {
    date: string;
    time: string;
    type: string;
    bookingType?: string;
  };
}

export function PaymentModal({ isOpen, onClose, courseTitle, amount, bookingDetails }: PaymentModalProps) {
  const { user } = useAuth();
  const [paymentMethod, setPaymentMethod] = useState<"card" | "mpesa">("card");
  const [isProcessing, setIsProcessing] = useState(false);
  const [cardNumber, setCardNumber] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [cvv, setCvv] = useState("");
  const [cardName, setCardName] = useState("");
  const [mpesaPhone, setMpesaPhone] = useState("");

  const generateTransactionId = () => {
    return `TXN${Date.now()}${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
  };

  const handleMpesaPayment = async () => {
    if (!user) {
      toast.error("Please log in to make a payment", {
        description: "Authentication is required for M-Pesa payments.",
      });
      return;
    }

    if (!mpesaPhone || mpesaPhone.length < 10) {
      toast.error("Please enter a valid M-Pesa phone number");
      return;
    }

    setIsProcessing(true);

    try {
      // Call Daraja STK Push edge function
      const { data, error } = await supabase.functions.invoke('mpesa-stk-push', {
        body: {
          phone: mpesaPhone,
          amount: amount,
          accountReference: courseTitle.substring(0, 12),
          transactionDesc: "Course Payment",
        },
      });

      if (error) {
        console.error("STK Push error:", error);
        toast.error("Failed to initiate M-Pesa payment. Please try again.");
        setIsProcessing(false);
        return;
      }

      if (data?.success) {
        // Insert pending payment record with checkoutRequestId
        const { error: paymentError } = await supabase
          .from("payments")
          .insert({
            user_id: user?.id || null,
            email: user?.email || "guest@example.com",
            course_title: courseTitle,
            amount: amount,
            currency: "KES",
            payment_method: "mpesa",
            payment_status: "pending",
            transaction_id: data.checkoutRequestId,
            training_type: bookingDetails.type.includes("Physical") ? "physical" : "virtual",
            training_date: bookingDetails.date,
            training_time: bookingDetails.time,
          });

        if (paymentError) {
          console.error("Failed to save payment record:", paymentError);
        }

        toast.success("STK Push sent to your phone!", {
          description: "Please check your phone and enter your M-Pesa PIN to complete payment.",
        });

        // Close modal after sending STK push
        setTimeout(() => {
          setIsProcessing(false);
          onClose();
          toast.info("Check your payment status in your account.", {
            description: "The payment will be confirmed once you complete the M-Pesa transaction.",
          });
        }, 3000);
      } else {
        toast.error(data?.message || "Failed to send STK Push. Please try again.");
        setIsProcessing(false);
      }
    } catch (error) {
      console.error("Payment error:", error);
      toast.error("An error occurred. Please try again.");
      setIsProcessing(false);
    }
  };

  const handleCardPayment = async () => {
    if (!cardNumber || !expiryDate || !cvv || !cardName) {
      toast.error("Please fill in all card details");
      return;
    }

    setIsProcessing(true);

    // Simulate card payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000));

    // Insert payment record into database
    const { error: paymentError } = await supabase
      .from("payments")
      .insert({
        user_id: user?.id || null,
        email: user?.email || "guest@example.com",
        course_title: courseTitle,
        amount: amount,
        currency: "KES",
        payment_method: "credit_card",
        payment_status: "completed",
        transaction_id: generateTransactionId(),
        training_type: bookingDetails.type.includes("Physical") ? "physical" : "virtual",
        training_date: bookingDetails.date,
        training_time: bookingDetails.time,
      });

    if (paymentError) {
      console.error("Failed to save payment record:", paymentError);
      toast.error("Payment recorded but failed to save. Contact support.");
    }

    // Send email notification
    if (user?.email) {
      try {
        await supabase.functions.invoke('send-notification-email', {
          body: {
            type: "booking_confirmation",
            to: user.email,
            data: {
              courseName: courseTitle,
              date: bookingDetails.date,
              time: bookingDetails.time,
              trainingType: bookingDetails.type,
              amount: amount,
              currency: "KES",
            },
          },
        });
      } catch (emailError) {
        console.error("Failed to send confirmation email:", emailError);
      }
    }

    toast.success("Payment successful!", {
      description: `Your booking for ${courseTitle} has been confirmed.`,
    });

    setIsProcessing(false);
    onClose();
  };

  const handlePayment = async () => {
    if (paymentMethod === "mpesa") {
      await handleMpesaPayment();
    } else {
      await handleCardPayment();
    }
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || "";
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    return parts.length ? parts.join(" ") : value;
  };

  const formatExpiry = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    if (v.length >= 2) {
      return v.substring(0, 2) + "/" + v.substring(2, 4);
    }
    return v;
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center gap-2">
            <Lock className="w-5 h-5 text-primary" />
            Secure Payment
          </DialogTitle>
        </DialogHeader>

        {/* Order Summary */}
        <div className="p-4 bg-muted rounded-xl space-y-2">
          <h3 className="font-semibold">{courseTitle}</h3>
          <div className="text-sm text-muted-foreground space-y-1">
            <p>Date: {bookingDetails.date}</p>
            <p>Time: {bookingDetails.time}</p>
            <p>Type: {bookingDetails.type}</p>
            {bookingDetails.bookingType && <p>Booking: {bookingDetails.bookingType}</p>}
          </div>
          <div className="pt-2 border-t border-border">
            <p className="text-lg font-bold text-primary">
              Total: KES {amount.toLocaleString()}
            </p>
          </div>
        </div>

        {/* Payment Method Selection */}
        <div className="space-y-4">
          <Label className="text-sm font-medium">Select Payment Method</Label>
          <RadioGroup
            value={paymentMethod}
            onValueChange={(v) => setPaymentMethod(v as "card" | "mpesa")}
            className="flex gap-4"
          >
            <div className="flex-1">
              <RadioGroupItem value="card" id="card" className="peer sr-only" />
              <Label
                htmlFor="card"
                className="flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5"
              >
                <CreditCard className="w-5 h-5 text-primary" />
                <div>
                  <p className="font-medium">Card</p>
                  <p className="text-xs text-muted-foreground">Visa/Mastercard</p>
                </div>
              </Label>
            </div>
            <div className="flex-1">
              <RadioGroupItem value="mpesa" id="mpesa" className="peer sr-only" />
              <Label
                htmlFor="mpesa"
                className="flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5"
              >
                <Smartphone className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-medium">M-Pesa</p>
                  <p className="text-xs text-muted-foreground">STK Push</p>
                </div>
              </Label>
            </div>
          </RadioGroup>

          {/* Card Payment Form */}
          {paymentMethod === "card" && (
            <div className="space-y-4 animate-fade-up">
              <div className="space-y-2">
                <Label htmlFor="cardName">Cardholder Name</Label>
                <Input
                  id="cardName"
                  placeholder="John Doe"
                  value={cardName}
                  onChange={(e) => setCardName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cardNumber">Card Number</Label>
                <Input
                  id="cardNumber"
                  placeholder="1234 5678 9012 3456"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                  maxLength={19}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="expiry">Expiry Date</Label>
                  <Input
                    id="expiry"
                    placeholder="MM/YY"
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(formatExpiry(e.target.value))}
                    maxLength={5}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cvv">CVV</Label>
                  <Input
                    id="cvv"
                    placeholder="123"
                    value={cvv}
                    onChange={(e) => setCvv(e.target.value.replace(/\D/g, "").slice(0, 3))}
                    maxLength={3}
                    type="password"
                  />
                </div>
              </div>
            </div>
          )}

          {/* M-Pesa Payment Form */}
          {paymentMethod === "mpesa" && (
            <div className="space-y-4 animate-fade-up">
              <div className="space-y-2">
                <Label htmlFor="mpesaPhone">M-Pesa Phone Number</Label>
                <Input
                  id="mpesaPhone"
                  placeholder="0712345678"
                  value={mpesaPhone}
                  onChange={(e) => setMpesaPhone(e.target.value.replace(/\D/g, "").slice(0, 12))}
                />
                <p className="text-xs text-muted-foreground">
                  You will receive an STK Push on this number
                </p>
              </div>
              <div className="p-3 bg-green-50 dark:bg-green-950 rounded-lg border border-green-200 dark:border-green-800">
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5" />
                  <div className="text-sm text-green-700 dark:text-green-300">
                    <p className="font-medium">How M-Pesa works:</p>
                    <ol className="list-decimal list-inside mt-1 space-y-1 text-xs">
                      <li>Click "Pay Now"</li>
                      <li>Check your phone for STK Push</li>
                      <li>Enter your M-Pesa PIN</li>
                      <li>Payment confirmed automatically</li>
                    </ol>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Pay Button */}
          <Button
            onClick={handlePayment}
            disabled={isProcessing}
            className="w-full hero-gradient border-0 hover:opacity-90"
            size="lg"
          >
            {isProcessing ? (
              <span className="flex items-center gap-2">
                <span className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                Processing...
              </span>
            ) : (
              `Pay KES ${amount.toLocaleString()}`
            )}
          </Button>

          <p className="text-xs text-center text-muted-foreground flex items-center justify-center gap-1">
            <Lock className="w-3 h-3" />
            Your payment is secured with 256-bit encryption
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
