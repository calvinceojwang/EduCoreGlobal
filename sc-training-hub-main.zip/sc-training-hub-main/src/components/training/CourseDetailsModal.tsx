import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Clock, Users, CheckCircle, Award, BookOpen, Target, Signal } from "lucide-react";
import { BookingModal } from "./BookingModal";

interface Course {
  id: string;
  title: string;
  category: string;
  duration: string;
  price: number;
  image: string;
  rating: number;
  students: number;
  description?: string;
  level?: string;
}

interface CourseDetailsModalProps {
  course: Course;
  isOpen: boolean;
  onClose: () => void;
}

const courseFeatures: Record<string, { description: string; features: string[]; outcomes: string[] }> = {
  "Full Stack Web Development": {
    description: "Master both frontend and backend development with modern technologies. Build complete web applications from scratch using industry-standard tools and best practices.",
    features: [
      "HTML5, CSS3, and JavaScript fundamentals",
      "React.js and modern frontend frameworks",
      "Node.js and Express backend development",
      "Database design with SQL and NoSQL",
      "API development and integration",
      "Deployment and DevOps basics"
    ],
    outcomes: [
      "Build complete web applications",
      "Work with databases and APIs",
      "Deploy applications to cloud platforms",
      "Industry-recognized certification"
    ]
  },
  "CPA Professional Certification": {
    description: "Comprehensive preparation for the Certified Public Accountant examination. Master accounting principles, auditing standards, and financial reporting requirements.",
    features: [
      "Financial Accounting and Reporting",
      "Auditing and Attestation",
      "Regulation and Business Law",
      "Business Environment and Concepts",
      "Ethics and Professional Standards",
      "Exam preparation strategies"
    ],
    outcomes: [
      "Pass the CPA examination",
      "Understand GAAP and IFRS standards",
      "Apply auditing procedures",
      "Professional certification credential"
    ]
  },
  "AWS Solutions Architect": {
    description: "Learn to design and deploy scalable, highly available systems on Amazon Web Services. Prepare for the AWS Solutions Architect certification exam.",
    features: [
      "AWS core services and architecture",
      "EC2, S3, RDS, and VPC configuration",
      "Security best practices and IAM",
      "High availability and disaster recovery",
      "Cost optimization strategies",
      "Hands-on labs and projects"
    ],
    outcomes: [
      "Design scalable cloud architectures",
      "Implement AWS security best practices",
      "Optimize cloud infrastructure costs",
      "AWS certification credential"
    ]
  },
  "Project Management Professional (PMP)": {
    description: "Prepare for the globally recognized PMP certification. Learn project management methodologies, tools, and techniques used by leading organizations worldwide.",
    features: [
      "Project initiation and planning",
      "Scope, schedule, and cost management",
      "Quality and risk management",
      "Stakeholder and communication management",
      "Agile and hybrid methodologies",
      "PMP exam preparation"
    ],
    outcomes: [
      "Lead projects effectively",
      "Apply PMI best practices",
      "Manage project risks and stakeholders",
      "PMP certification credential"
    ]
  }
};

const defaultCourseInfo = {
  description: "This comprehensive training program is designed to equip you with practical skills and knowledge required in today's competitive job market. Our expert instructors provide hands-on training with real-world projects.",
  features: [
    "Expert-led instruction",
    "Hands-on practical exercises",
    "Real-world case studies",
    "Comprehensive course materials",
    "Interactive learning sessions",
    "Post-training support"
  ],
  outcomes: [
    "Industry-relevant skills",
    "Certificate of Completion",
    "Career advancement opportunities",
    "Networking with professionals"
  ]
};

export function CourseDetailsModal({ course, isOpen, onClose }: CourseDetailsModalProps) {
  const [showBooking, setShowBooking] = useState(false);

  const courseInfo = courseFeatures[course.title] || defaultCourseInfo;

  const handleBookNow = () => {
    setShowBooking(true);
  };

  const handleBookingClose = () => {
    setShowBooking(false);
    onClose();
  };

  return (
    <>
      <Dialog open={isOpen && !showBooking} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">{course.title}</DialogTitle>
          </DialogHeader>

          {/* Course Image and Basic Info */}
          <div className="relative aspect-[3/1] rounded-xl overflow-hidden mb-6">
            <img
              src={course.image}
              alt={course.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute top-3 left-3 flex gap-2">
              <Badge variant="secondary" className="bg-card/90 backdrop-blur-sm text-xs">
                {course.category}
              </Badge>
              {course.level && (
                <Badge 
                  variant="secondary" 
                  className={`backdrop-blur-sm text-xs flex items-center gap-1 ${
                    course.level === "Advanced" 
                      ? "bg-primary/90 text-primary-foreground" 
                      : "bg-accent/90 text-accent-foreground"
                  }`}
                >
                  <Signal className="w-3 h-3" />
                  {course.level}
                </Badge>
              )}
            </div>
          </div>

          {/* Stats */}
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="flex items-center gap-2 px-4 py-2 bg-muted rounded-lg">
              <Clock className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">{course.duration}</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-muted rounded-lg">
              <Users className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">{course.students.toLocaleString()} students</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-muted rounded-lg">
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              <span className="text-sm font-medium">{course.rating} rating</span>
            </div>
          </div>

          {/* Description */}
          <div className="mb-6">
            <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-primary" />
              About This Course
            </h3>
            <p className="text-muted-foreground leading-relaxed">
              {courseInfo.description}
            </p>
          </div>

          {/* What You'll Learn */}
          <div className="mb-6">
            <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
              <Target className="w-5 h-5 text-primary" />
              What You'll Learn
            </h3>
            <ul className="grid sm:grid-cols-2 gap-3">
              {courseInfo.features.map((feature, index) => (
                <li key={index} className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-muted-foreground">{feature}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Learning Outcomes */}
          <div className="mb-6">
            <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
              <Award className="w-5 h-5 text-primary" />
              What You'll Achieve
            </h3>
            <ul className="space-y-2">
              {courseInfo.outcomes.map((outcome, index) => (
                <li key={index} className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                  <span className="text-sm">{outcome}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Price and Book Now */}
          <div className="flex items-center justify-between pt-6 border-t border-border">
            <div>
              <p className="text-sm text-muted-foreground">Course Fee</p>
              <p className="text-2xl font-bold text-primary">
                KES {course.price.toLocaleString()}
              </p>
            </div>
            <Button
              onClick={handleBookNow}
              size="lg"
              className="hero-gradient border-0 hover:opacity-90 px-8"
            >
              Book Now
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Booking Modal */}
      <BookingModal
        course={course}
        isOpen={showBooking}
        onClose={handleBookingClose}
      />
    </>
  );
}
