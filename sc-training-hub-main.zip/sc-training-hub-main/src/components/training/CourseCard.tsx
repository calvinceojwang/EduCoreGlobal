import { useState } from "react";
import { Star, Clock, Users, Signal } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { CourseDetailsModal } from "./CourseDetailsModal";

interface Course {
  id: string;
  title: string;
  category: string;
  duration: string;
  price: number;
  image: string;
  rating: number;
  students: number;
  description?: string;
  level?: string;
}

interface CourseCardProps {
  course: Course;
  className?: string;
}

export function CourseCard({ course, className }: CourseCardProps) {
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);

  return (
    <>
      <div
        className={cn(
          "group bg-card rounded-xl overflow-hidden card-shadow hover:card-shadow-hover transition-all duration-300 hover:-translate-y-1 cursor-pointer",
          className
        )}
        onClick={() => setIsDetailsOpen(true)}
      >
        {/* Image */}
        <div className="relative aspect-[16/9] overflow-hidden">
          <img
            src={course.image}
            alt={course.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <div className="absolute top-1.5 left-1.5">
            <span className="px-1.5 py-0.5 rounded-full bg-card/90 backdrop-blur-sm text-[9px] font-medium">
              {course.category}
            </span>
          </div>
          {course.level && (
            <div className="absolute top-1.5 right-1.5">
              <span className={cn(
                "px-1.5 py-0.5 rounded-full backdrop-blur-sm text-[9px] font-medium flex items-center gap-0.5",
                course.level === "Advanced" 
                  ? "bg-primary/90 text-primary-foreground" 
                  : "bg-accent/90 text-accent-foreground"
              )}>
                <Signal className="w-2 h-2" />
                {course.level}
              </span>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-2">
          <h3 className="font-semibold text-xs mb-1 line-clamp-2 group-hover:text-primary transition-colors leading-tight">
            {course.title}
          </h3>

          <div className="flex items-center gap-2 text-[10px] text-muted-foreground mb-1.5">
            <div className="flex items-center gap-0.5">
              <Clock className="w-2.5 h-2.5" />
              {course.duration}
            </div>
            <div className="flex items-center gap-0.5">
              <Users className="w-2.5 h-2.5" />
              {course.students.toLocaleString()}
            </div>
          </div>

          <div className="flex items-center justify-between pt-1.5 border-t border-border mb-1.5">
            <div className="flex items-center gap-0.5">
              <Star className="w-2.5 h-2.5 fill-amber-400 text-amber-400" />
              <span className="text-[10px] font-medium">{course.rating}</span>
            </div>
            <span className="text-xs font-bold text-primary">
              KES {course.price.toLocaleString()}
            </span>
          </div>

          <Button 
            onClick={(e) => {
              e.stopPropagation();
              setIsDetailsOpen(true);
            }}
            size="sm"
            className="w-full hero-gradient border-0 hover:opacity-90 text-[10px] h-6"
          >
            View Details
          </Button>
        </div>
      </div>

      <CourseDetailsModal
        course={course}
        isOpen={isDetailsOpen}
        onClose={() => setIsDetailsOpen(false)}
      />
    </>
  );
}
