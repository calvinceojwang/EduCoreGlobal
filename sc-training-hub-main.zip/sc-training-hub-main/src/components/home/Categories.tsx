import { Link } from "react-router-dom";
import { Code2, Calculator, Award, BookMarked, TrendingUp, Database, Shield, Briefcase } from "lucide-react";

const categories = [
  {
    icon: Code2,
    name: "Computer Science",
    courses: 45,
    color: "bg-blue-500/10 text-blue-600",
    link: "/training?category=cs",
  },
  {
    icon: Calculator,
    name: "Finance & Accounting",
    courses: 30,
    color: "bg-green-500/10 text-green-600",
    link: "/training?category=finance",
  },
  {
    icon: Award,
    name: "Professional Certifications",
    courses: 50,
    color: "bg-purple-500/10 text-purple-600",
    link: "/training?category=certifications",
  },
  {
    icon: Database,
    name: "Data Science & AI",
    courses: 25,
    color: "bg-cyan-500/10 text-cyan-600",
    link: "/training?category=data",
  },
  {
    icon: Shield,
    name: "Cybersecurity",
    courses: 18,
    color: "bg-red-500/10 text-red-600",
    link: "/training?category=security",
  },
  {
    icon: TrendingUp,
    name: "Business & Management",
    courses: 22,
    color: "bg-amber-500/10 text-amber-600",
    link: "/training?category=business",
  },
  {
    icon: Briefcase,
    name: "Project Management",
    courses: 15,
    color: "bg-indigo-500/10 text-indigo-600",
    link: "/training?category=pm",
  },
  {
    icon: BookMarked,
    name: "Miscellaneous",
    courses: 35,
    color: "bg-pink-500/10 text-pink-600",
    link: "/training?category=misc",
  },
];

export function Categories() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">Explore Our Categories</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Browse through our comprehensive catalog of courses designed to help you excel in your career
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {categories.map((category, index) => (
            <Link
              key={category.name}
              to={category.link}
              className="group p-6 bg-card rounded-2xl card-shadow hover:card-shadow-hover transition-all duration-300 hover:-translate-y-1"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className={`w-14 h-14 rounded-xl ${category.color} flex items-center justify-center mb-4 transition-transform group-hover:scale-110`}>
                <category.icon className="w-7 h-7" />
              </div>
              <h3 className="font-semibold text-lg mb-1 group-hover:text-primary transition-colors">
                {category.name}
              </h3>
              <p className="text-sm text-muted-foreground">{category.courses} courses</p>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
