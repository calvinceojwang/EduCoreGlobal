import { CheckCircle2, Laptop, Users2, Clock, Award, HeadphonesIcon } from "lucide-react";

const features = [
  {
    icon: Laptop,
    title: "Flexible Learning",
    description: "Choose between physical classes or virtual training sessions to fit your schedule",
  },
  {
    icon: Users2,
    title: "Expert Instructors",
    description: "Learn from industry professionals with real-world experience and expertise",
  },
  {
    icon: Clock,
    title: "5-Day Intensive Programs",
    description: "Our structured curriculum ensures you master skills efficiently in just 5 days",
  },
  {
    icon: Award,
    title: "Recognized Certifications",
    description: "Earn certificates that are valued by employers across industries",
  },
  {
    icon: HeadphonesIcon,
    title: "Dedicated Support",
    description: "Get help whenever you need it with our responsive support team",
  },
  {
    icon: CheckCircle2,
    title: "Hands-On Training",
    description: "Practice with real projects and scenarios to build practical skills",
  },
];

export function WhyChooseUs() {
  return (
    <section className="py-20 bg-foreground text-primary-foreground relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-primary/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-accent/20 rounded-full blur-3xl" />
      
      <div className="container mx-auto px-4 relative">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">Why Choose SC Hosting?</h2>
          <p className="opacity-70 max-w-2xl mx-auto">
            We're committed to providing the best learning experience for our students
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="p-6 rounded-2xl bg-primary-foreground/5 border border-primary-foreground/10 hover:bg-primary-foreground/10 transition-colors"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center mb-4">
                <feature.icon className="w-6 h-6 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="opacity-70 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
