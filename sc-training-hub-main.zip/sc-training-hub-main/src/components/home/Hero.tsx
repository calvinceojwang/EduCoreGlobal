import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { ArrowRight, Play, Users, Award, BookOpen, X, Video } from "lucide-react";

function DemoVideoModal() {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <>
      <Button 
        size="lg" 
        variant="outline" 
        className="gap-2 group"
        onClick={() => setIsOpen(true)}
      >
        <Play className="w-4 h-4" />
        Watch Demo
      </Button>
      
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden bg-black border-none">
          <button
            onClick={() => setIsOpen(false)}
            className="absolute right-4 top-4 z-50 rounded-full bg-white/10 p-2 hover:bg-white/20 transition-colors"
          >
            <X className="w-5 h-5 text-white" />
          </button>
          <div className="aspect-video">
            <video
              autoPlay
              controls
              className="w-full h-full"
              src="https://videos.pexels.com/video-files/3130182/3130182-uhd_2560_1440_30fps.mp4"
            />
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

const stats = [
  { icon: Users, value: "10,000+", label: "Students Trained" },
  { icon: Award, value: "50+", label: "Certifications" },
  { icon: BookOpen, value: "200+", label: "Courses" },
];

export function Hero() {
  return (
    <section className="relative overflow-hidden min-h-[90vh] flex items-center">
      {/* Background Video */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover"
      >
        <source
          src="https://videos.pexels.com/video-files/3130182/3130182-uhd_2560_1440_30fps.mp4"
          type="video/mp4"
        />
      </video>
      {/* Overlay for text readability */}
      <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-background/60" />
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-primary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      
      <div className="container mx-auto px-4 py-20 lg:py-32 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Content */}
          <div className="space-y-8 animate-fade-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              Now Enrolling for 2026 Sessions
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight">
              Start Your Training Journey with{" "}
              <span className="text-gradient">SC Hosting</span>
            </h1>
            
            <p className="text-lg text-muted-foreground max-w-lg leading-relaxed">
              Unlock your potential with expert-led training in Computer Science, Finance & Accounting, 
              and professional certifications. Learn from industry leaders and advance your career.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <Link to="/training">
                <Button size="lg" className="hero-gradient border-0 gap-2 group hover:opacity-90 transition-opacity">
                  Explore Courses
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </Button>
              </Link>
              <Link to="/webinars">
                <Button size="lg" variant="secondary" className="gap-2">
                  <Video className="w-4 h-4" />
                  Webinars
                </Button>
              </Link>
              <DemoVideoModal />
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8 pt-8 border-t border-border">
              {stats.map((stat) => (
                <div key={stat.label} className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <stat.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{stat.value}</p>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Visual */}
          <div className="relative lg:block hidden">
            <div className="relative z-10 animate-float">
              <div className="bg-card rounded-3xl p-8 card-shadow">
                <div className="aspect-video rounded-2xl hero-gradient flex items-center justify-center">
                  <div className="text-center text-primary-foreground">
                    <BookOpen className="w-16 h-16 mx-auto mb-4" />
                    <p className="text-xl font-semibold">World-Class Training</p>
                    <p className="text-sm opacity-80">Physical & Virtual Classes</p>
                  </div>
                </div>
                <div className="mt-6 space-y-4">
                  <div className="flex items-center gap-4">
                    <div className="w-3 h-3 rounded-full bg-accent" />
                    <span className="text-sm font-medium">Computer Science</span>
                    <span className="ml-auto text-sm text-muted-foreground">45+ courses</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-3 h-3 rounded-full bg-primary" />
                    <span className="text-sm font-medium">Finance & Accounting</span>
                    <span className="ml-auto text-sm text-muted-foreground">30+ courses</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-3 h-3 rounded-full bg-green-500" />
                    <span className="text-sm font-medium">Certifications</span>
                    <span className="ml-auto text-sm text-muted-foreground">50+ programs</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -top-8 -right-8 w-64 h-64 bg-accent/20 rounded-full blur-3xl" />
            <div className="absolute -bottom-8 -left-8 w-48 h-48 bg-primary/20 rounded-full blur-2xl" />
          </div>
        </div>
      </div>
    </section>
  );
}
