import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { CourseCard } from "@/components/training/CourseCard";
import { ArrowRight } from "lucide-react";

const featuredCourses = [
  {
    id: "1",
    title: "Full Stack Web Development",
    category: "Computer Science",
    duration: "5 Days",
    price: 45000,
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600&h=400&fit=crop",
    rating: 4.9,
    students: 2340,
  },
  {
    id: "2",
    title: "CPA Professional Certification",
    category: "Finance & Accounting",
    duration: "5 Days",
    price: 55000,
    image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=600&h=400&fit=crop",
    rating: 4.8,
    students: 1890,
  },
  {
    id: "3",
    title: "AWS Solutions Architect",
    category: "Certifications",
    duration: "5 Days",
    price: 65000,
    image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600&h=400&fit=crop",
    rating: 4.9,
    students: 1560,
  },
  {
    id: "4",
    title: "Project Management Professional (PMP)",
    category: "Certifications",
    duration: "5 Days",
    price: 70000,
    image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop",
    rating: 4.7,
    students: 2100,
  },
];

export function FeaturedCourses() {
  return (
    <section className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-12">
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold mb-2">Featured Courses</h2>
            <p className="text-muted-foreground">Most popular training programs chosen by our students</p>
          </div>
          <Link to="/training">
            <Button variant="outline" className="gap-2 group">
              View All Courses
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </Button>
          </Link>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredCourses.map((course, index) => (
            <div
              key={course.id}
              className="animate-fade-up"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CourseCard course={course} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
