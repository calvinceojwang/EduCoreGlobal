import type { Session } from "@supabase/supabase-js";
import {
  getSupabaseServerClient,
  parseJsonBody,
  rejectInvalidMethod,
  sendError,
  validatePasswordMinimum,
} from "./_shared";

interface LoginBody {
  email: string;
  password: string;
}

interface ApiRequest {
  method?: string;
  body?: unknown;
}

interface ApiResponse {
  status: (code: number) => {
    json: (payload: unknown) => void;
  };
}

export default async function handler(req: ApiRequest, res: ApiResponse) {
  if (rejectInvalidMethod(req, res)) return;

  const { email, password } = parseJsonBody<LoginBody>(req);
  const passwordError = validatePasswordMinimum(password);
  if (passwordError) {
    sendError(res, 400, passwordError);
    return;
  }

  try {
    const supabase = getSupabaseServerClient();
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });

    if (error) {
      sendError(res, 401, error.message);
      return;
    }

    let isAdmin = false;
    if (data.user?.id) {
      const { data: hasRole, error: roleError } = await supabase.rpc("has_role", {
        _user_id: data.user.id,
        _role: "admin",
      });

      if (!roleError) {
        isAdmin = !!hasRole;
      }
    }

    res.status(200).json({
      data: {
        user: data.user,
        session: data.session as Session | null,
        isAdmin,
      },
    });
  } catch {
    sendError(res, 500, "Failed to complete login request");
  }
}

