import { createClient } from "@supabase/supabase-js";

const PASSWORD_ERROR_MESSAGE = "Password must be at least 6 characters";

interface ApiResponseShape {
  status: (code: number) => {
    json: (payload: unknown) => void;
  };
}

interface ApiRequestShape {
  method?: string;
  body?: unknown;
}

export function getSupabaseServerClient() {
  const url = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
  const anonKey = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.VITE_SUPABASE_PUBLISHABLE_KEY;

  if (!url || !anonKey) {
    throw new Error("Missing Supabase server environment variables.");
  }

  return createClient(url, anonKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });
}

export function parseJsonBody<T>(req: ApiRequestShape): T {
  if (typeof req.body === "string") {
    return JSON.parse(req.body) as T;
  }
  return (req.body || {}) as T;
}

export function rejectInvalidMethod(req: ApiRequestShape, res: ApiResponseShape): boolean {
  if (req.method !== "POST") {
    res.status(405).json({ error: "Method not allowed" });
    return true;
  }
  return false;
}

export function validatePasswordMinimum(password: string): string | null {
  if (!password || password.length < 6) {
    return PASSWORD_ERROR_MESSAGE;
  }
  return null;
}

export function sendError(res: ApiResponseShape, statusCode: number, message: string) {
  res.status(statusCode).json({ error: message });
}

