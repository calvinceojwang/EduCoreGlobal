import {
  getSupabaseServerClient,
  parseJsonBody,
  rejectInvalidMethod,
  sendError,
  validatePasswordMinimum,
} from "./_shared";

interface ResetPasswordBody {
  password: string;
  accessToken: string;
  refreshToken: string;
}

interface ApiRequest {
  method?: string;
  body?: unknown;
}

interface ApiResponse {
  status: (code: number) => {
    json: (payload: unknown) => void;
  };
}

export default async function handler(req: ApiRequest, res: ApiResponse) {
  if (rejectInvalidMethod(req, res)) return;

  const body = parseJsonBody<ResetPasswordBody>(req);
  const passwordError = validatePasswordMinimum(body.password);
  if (passwordError) {
    sendError(res, 400, passwordError);
    return;
  }

  if (!body.accessToken || !body.refreshToken) {
    sendError(res, 400, "Invalid or expired reset link");
    return;
  }

  try {
    const supabase = getSupabaseServerClient();
    const { error: sessionError } = await supabase.auth.setSession({
      access_token: body.accessToken,
      refresh_token: body.refreshToken,
    });

    if (sessionError) {
      sendError(res, 401, "Invalid or expired reset link");
      return;
    }

    const { error } = await supabase.auth.updateUser({ password: body.password });
    if (error) {
      sendError(res, 400, error.message);
      return;
    }

    res.status(200).json({
      data: {
        updated: true,
      },
    });
  } catch {
    sendError(res, 500, "Failed to reset password");
  }
}

