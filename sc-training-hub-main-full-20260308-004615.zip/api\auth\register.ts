import type { Session } from "@supabase/supabase-js";
import {
  getSupabaseServerClient,
  parseJsonBody,
  rejectInvalidMethod,
  sendError,
  validatePasswordMinimum,
} from "./_shared";

interface RegisterBody {
  email: string;
  password: string;
  fullName: string;
  phone: string;
  emailRedirectTo: string;
}

interface ApiRequest {
  method?: string;
  body?: unknown;
}

interface ApiResponse {
  status: (code: number) => {
    json: (payload: unknown) => void;
  };
}

export default async function handler(req: ApiRequest, res: ApiResponse) {
  if (rejectInvalidMethod(req, res)) return;

  const body = parseJsonBody<RegisterBody>(req);
  const passwordError = validatePasswordMinimum(body.password);
  if (passwordError) {
    sendError(res, 400, passwordError);
    return;
  }

  try {
    const supabase = getSupabaseServerClient();
    const { data, error } = await supabase.auth.signUp({
      email: body.email,
      password: body.password,
      options: {
        emailRedirectTo: body.emailRedirectTo,
        data: {
          full_name: body.fullName,
          phone: body.phone,
        },
      },
    });

    if (error) {
      sendError(res, 400, error.message);
      return;
    }

    res.status(200).json({
      data: {
        user: data.user,
        session: data.session as Session | null,
      },
    });
  } catch {
    sendError(res, 500, "Failed to complete registration request");
  }
}

